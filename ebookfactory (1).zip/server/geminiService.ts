import { GoogleGenAI, Type } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please configure it in your Settings > Secrets.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

export async function generateEbookOutline(niche: string, tone: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Create a comprehensive ebook outline for the niche: "${niche}". 
    The tone should be ${tone}. 
    Include a title, subtitle, and 5-7 chapter titles with brief descriptions of what each chapter covers.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          subtitle: { type: Type.STRING },
          chapters: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["title", "description"]
            }
          }
        },
        required: ["title", "subtitle", "chapters"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    console.error("Failed to parse outline JSON:", e);
    return { title: niche, subtitle: "", chapters: [] };
  }
}

export async function generateChapterContent(title: string, chapterTitle: string, chapterDescription: string, tone: string, depth: string, writingStyle: string = "conversational") {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Write a full chapter for an ebook titled "${title}". 
    Chapter Title: "${chapterTitle}"
    Context: ${chapterDescription}
    Tone: ${tone}
    Depth: ${depth}
    Writing Style: ${writingStyle}
    
    Format the output in Markdown. Include a hook, key takeaways, and actionable steps.`,
  });

  return response.text || "";
}

export async function generateCoverArt(title: string, niche: string, keywords: string = "", style: string = "modern, minimalist") {
  const ai = getGeminiClient();
  const prompt = `Create a professional and visually stunning ebook cover.
  Book Title: "${title}"
  Niche/Subject: "${niche}"
  Keywords to incorporate: ${keywords}
  Artistic Style: ${style}
  
  The design should be cohesive, high-resolution, and have clean typography that is brand-aligned with the ${niche} niche. 
  Ensure the visual elements directly relate to the title and niche for a professional look.`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: {
      parts: [
        { text: prompt }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "3:4",
        imageSize: "1K"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}

export async function generateChapterSummary(chapterTitle: string, content: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Create a concise, one-paragraph summary for the following ebook chapter titled "${chapterTitle}".
    
    Content: "${content}"
    
    The summary should be engaging and highlight the main points.`,
  });

  return response.text || "";
}

export async function generateChapterImage(chapterTitle: string, chapterDescription: string, style: string = "modern, minimalist, clean lines") {
  const ai = getGeminiClient();
  const prompt = `Create a high-quality, professional illustration for an ebook chapter.
  Chapter Title: "${chapterTitle}"
  Context/Theme: ${chapterDescription}
  Artistic Style: ${style}
  
  The image should be visually evocative, capturing the essence of the chapter's topic. 
  It should be designed as a professional book illustration, with attention to composition, lighting, and mood.
  Ensure the style "${style}" is deeply integrated into the visual execution.
  The image should be clean, high-resolution, and suitable for a professional publication.
  IMPORTANT: Do not include any text, letters, or words in the image. No people if possible, focus on objects, concepts, or landscapes.`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: {
      parts: [
        { text: prompt }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
        imageSize: "1K"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}

export async function checkGrammar(text: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Review the following text for grammar, spelling, punctuation, and stylistic improvements. 
    Focus on making the writing more professional, engaging, and clear while maintaining the original meaning and tone.
    
    Structure your response as a JSON object with:
    1. "improvedText": The complete corrected version of the text in Markdown.
    2. "suggestions": An array of specific changes made, each with:
       - "original": The original snippet.
       - "improved": The improved version.
       - "explanation": Why this change was made (e.g., "Corrected subject-verb agreement", "Changed to a more active voice").
    
    Text: "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          improvedText: { type: Type.STRING },
          suggestions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                original: { type: Type.STRING },
                improved: { type: Type.STRING },
                explanation: { type: Type.STRING }
              },
              required: ["original", "improved", "explanation"]
            }
          }
        },
        required: ["improvedText", "suggestions"]
      }
    }
  });

  try {
    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    return {
      improvedText: data.improvedText || rawText,
      suggestions: data.suggestions || []
    };
  } catch (e) {
    console.error("Failed to parse grammar JSON:", e);
    return { 
      improvedText: response.text || text, 
      suggestions: [] 
    };
  }
}

export async function translateChapter(title: string, content: string, targetLanguage: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Translate the following ebook chapter into ${targetLanguage}.
    
    Chapter Title: "${title}"
    Chapter Content: "${content}"
    
    Maintain all Markdown formatting, structure, and tone. 
    Return the translated title and content in JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          content: { type: Type.STRING }
        },
        required: ["title", "content"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}") as { title: string, content: string };
  } catch (e) {
    console.error("Failed to parse translation JSON:", e);
    return { title, content };
  }
}

export async function analyzeTrendingNiches() {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Analyze current globally trending topics suitable for high-profit ebook niches on platforms like Amazon KDP.
    Identify 5 distinct, high-impact niches that currently have high search volume but potentially manageable competition.
    Each niche should include:
    1. A descriptive title.
    2. A brief explanation of why it is trending (market demand).
    3. Estimated potential (High/Medium).
    4. Estimated competition (Low/Medium/High).
    5. Primary target audience.
    
    Structure the response as a JSON array of niche objects.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            marketTrend: { type: Type.STRING },
            potential: { type: Type.STRING },
            competition: { type: Type.STRING },
            audience: { type: Type.STRING },
            timeToMarket: { type: Type.STRING }
          },
          required: ["id", "title", "marketTrend", "potential", "competition", "audience", "timeToMarket"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse trending niches JSON:", e);
    return [];
  }
}

export async function researchTopic(topic: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Conduct deep research on the topic: "${topic}". 
    Provide a 200-300 word evidence summary with at least 3 distinct, verifiable facts or studies found via Google Search.
    Focus on finding credible sources (academic, professional organizations, major news outlets).
    Include source URLs at the end.`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  return response.text || "";
}

export async function factCheckContent(content: string, niche?: string, tone?: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Analyze the following text and identify key factual claims. 
    Crucially, evaluate these claims within the context of the "${niche || 'general'}" niche and respect the structural context of the "${tone || 'neutral'}" tone. Ensure any stylistic exaggerations inherent to the tone are handled gracefully, but flag objective falsehoods.
    For each claim, use Google Search to verify its accuracy.
    Return a list of claims with:
    1. The original claim text.
    2. Verification status (accurate, inaccurate, partially_accurate, or unverified).
    3. A confidence score (0-100).
    4. Supporting evidence or counter-evidence found (ensure evidence directly addresses the claim).
    5. Source URLs.
    
    Text: "${content}"`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          claims: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                claim: { type: Type.STRING },
                status: { type: Type.STRING, enum: ["accurate", "inaccurate", "partially_accurate", "unverified"] },
                confidence: { type: Type.NUMBER },
                evidence: { type: Type.STRING },
                sources: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ["claim", "status", "confidence", "evidence", "sources"]
            }
          }
        },
        required: ["claims"]
      }
    }
  });

  try {
    return JSON.parse(response.text || '{"claims": []}') as { 
      claims: Array<{
        claim: string;
        status: 'accurate' | 'inaccurate' | 'partially_accurate' | 'unverified';
        confidence: number;
        evidence: string;
        sources: string[];
      }>
    };
  } catch (e) {
    console.error("Failed to parse fact-check JSON:", e);
    return { claims: [] };
  }
}

export async function generateDetailedNicheReport(topic: string) {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: `Perform a comprehensive NicheMaster market intelligence report for the topic or niche: "${topic}".
    Utilize live search grounding if helpful.
    Analyze search demand, competition intensity, estimated monthly ebook royalty potential, audience buyer persona, keyword clusters, competitor market gaps, 3 high-converting ebook titles/angles, and a 5-point validation checklist.
    
    Return strict JSON matching the schema.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING },
          opportunityScore: { type: Type.NUMBER },
          demandLevel: { type: Type.STRING },
          demandScore: { type: Type.NUMBER },
          competitionLevel: { type: Type.STRING },
          profitPotential: { type: Type.STRING },
          trendDirection: { type: Type.STRING },
          searchVolume: { type: Type.STRING },
          keywordClusters: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                keyword: { type: Type.STRING },
                volume: { type: Type.STRING },
                difficulty: { type: Type.STRING },
                intent: { type: Type.STRING }
              },
              required: ["keyword", "volume", "difficulty", "intent"]
            }
          },
          targetAudience: {
            type: Type.OBJECT,
            properties: {
              personaName: { type: Type.STRING },
              ageRange: { type: Type.STRING },
              painPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
              buyingTriggers: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["personaName", "ageRange", "painPoints", "buyingTriggers"]
          },
          competitorNotes: {
            type: Type.OBJECT,
            properties: {
              marketGap: { type: Type.STRING },
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              pricePointRange: { type: Type.STRING }
            },
            required: ["marketGap", "weaknesses", "pricePointRange"]
          },
          suggestedAngles: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                subtitle: { type: Type.STRING },
                hook: { type: Type.STRING },
                targetPrice: { type: Type.NUMBER }
              },
              required: ["title", "subtitle", "hook", "targetPrice"]
            }
          },
          validationChecklist: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING },
                passed: { type: Type.BOOLEAN },
                note: { type: Type.STRING }
              },
              required: ["item", "passed", "note"]
            }
          }
        },
        required: [
          "topic", "opportunityScore", "demandLevel", "demandScore", "competitionLevel", 
          "profitPotential", "trendDirection", "searchVolume", "keywordClusters", 
          "targetAudience", "competitorNotes", "suggestedAngles", "validationChecklist"
        ]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    console.error("Failed to parse detailed niche report JSON:", e);
    return {
      topic,
      opportunityScore: 78,
      demandLevel: "High",
      demandScore: 82,
      competitionLevel: "Medium",
      profitPotential: "$1,800 - $3,500/mo",
      trendDirection: "Upward",
      searchVolume: "28,000 searches/mo",
      keywordClusters: [
        { keyword: `${topic} guide`, volume: "12,000", difficulty: "Medium", intent: "Informational" },
        { keyword: `best ${topic} ebook`, volume: "5,400", difficulty: "Low", intent: "Commercial" }
      ],
      targetAudience: {
        personaName: "Driven Learner",
        ageRange: "25-45",
        painPoints: ["Lack of clear step-by-step roadmap", "Information overload"],
        buyingTriggers: ["Wants immediate practical results", "Saves time"]
      },
      competitorNotes: {
        marketGap: "Current books are overly theoretical and lack practical templates.",
        weaknesses: ["Outdated information", "No actionable checklists"],
        pricePointRange: "$9.99 - $24.99"
      },
      suggestedAngles: [
        {
          title: `The Ultimate ${topic} Playbook`,
          subtitle: "A practical step-by-step guide to mastering the craft",
          hook: "Transform your understanding in 7 simple chapters with zero fluff.",
          targetPrice: 14.99
        }
      ],
      validationChecklist: [
        { item: "High Search Intent Volume", passed: true, note: "Sufficient search demand detected" },
        { item: "Monetization Readiness", passed: true, note: "Strong ebook purchasing intent" }
      ]
    };
  }
}

