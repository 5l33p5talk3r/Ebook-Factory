import React from 'react';
import { ShieldAlert, ArrowLeft } from 'lucide-react';

interface AccessDeniedViewProps {
  onGoToStorefront: () => void;
  featureName?: string;
}

export const AccessDeniedView: React.FC<AccessDeniedViewProps> = ({
  onGoToStorefront,
  featureName = "Creator Studio & Admin Panel"
}) => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-[#131622] border border-[#2B3045] rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
        {/* Decorative Top Accent Bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-[#E5C158] to-red-500" />

        <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-red-950/40 border border-red-500/30 flex items-center justify-center text-red-400 shadow-inner">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <span className="inline-block px-3 py-1 bg-red-500/10 border border-red-500/20 text-red-400 rounded-full text-[10px] font-bold uppercase tracking-widest mb-3">
          Restricted Path
        </span>

        <h2 className="text-2xl font-serif font-bold text-white tracking-tight mb-2">
          Administrator Access Required
        </h2>

        <p className="text-slate-300 text-xs leading-relaxed mb-8">
          The <strong className="text-white">{featureName}</strong> is restricted to verified platform administrators. Standard customer accounts can browse the public Storefront, purchase books, and access their personal Reader Library.
        </p>

        <div className="flex flex-col gap-3">
          <button
            onClick={onGoToStorefront}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B58A28] text-black font-semibold text-xs shadow-lg hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Public Storefront
          </button>
        </div>
      </div>
    </div>
  );
};
