import React, { useState, useEffect, useRef } from 'react';
import { auth, db, storage, testFirestoreConnection } from './lib/firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User } from 'firebase/auth';
import { collection, query, where, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, deleteDoc, getDocs, orderBy, arrayUnion, arrayRemove, or, setDoc, getDoc } from 'firebase/firestore';
import { ref, uploadString, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { useEditor, EditorContent } from '@tiptap/react';
import { Extension } from '@tiptap/core';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Plugin } from 'prosemirror-state';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Placeholder from '@tiptap/extension-placeholder';
import TextAlign from '@tiptap/extension-text-align';
import Image from '@tiptap/extension-image';
import { TextStyle } from '@tiptap/extension-text-style';
import { Markdown } from 'tiptap-markdown';
import { toast, Toaster } from 'sonner';
import JSZip from 'jszip';
import { exportToZip, exportToEpub, exportToPdf } from './lib/exportUtils';
import { 
  cacheProject, 
  getCachedProject, 
  getCachedProjects, 
  cacheChapter, 
  getCachedChapter, 
  getCachedChaptersForProject, 
  queueOfflineAction, 
  getPendingOfflineActions, 
  removeOfflineAction 
} from './lib/offlineDb';
import { handleAIError, classifyAIError } from './lib/error-handling';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string;
    email?: string | null;
    emailVerified?: boolean;
    isAnonymous?: boolean;
    tenantId?: string | null;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMsg = error instanceof Error ? error.message : String(error);
  const errorCode = (error as any)?.code;
  const isConnectionIssue = 
    errorCode === 'unavailable' || 
    errorMsg.includes('unavailable') || 
    errorMsg.includes('Could not reach Cloud Firestore backend') || 
    errorMsg.includes('the client is offline') ||
    errorMsg.includes('failed-precondition');

  const errInfo: FirestoreErrorInfo = {
    error: errorMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };

  if (isConnectionIssue) {
    console.warn('Firestore intermittent connection issue (running in offline-ready mode):', JSON.stringify(errInfo));
    return; // Don't crash or show distracting error toasts for standard connection retry behavior
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  toast.error(`Database error: ${errInfo.error}`);
  throw new Error(JSON.stringify(errInfo));
}

import { 
  BookOpen, 
  Upload, 
  Settings, 
  Image as ImageIcon, 
  Send, 
  Download, 
  Plus, 
  LogOut, 
  ChevronRight, 
  CheckCircle2, 
  Loader2,
  AlertCircle,
  FileText,
  Mic,
  Sparkles,
  ArrowLeft,
  Trash2,
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote,
  Undo,
  Redo,
  Link as LinkIcon,
  Underline as UnderlineIcon,
  Heading1,
  Heading2,
  Save,
  Edit2,
  X,
  Eye,
  Maximize2,
  Minimize2,
  FileCode,
  Layout,
  Languages,
  ExternalLink,
  GripVertical,
  Strikethrough,
  Code,
  AlignLeft,
  AlignCenter,
  AlignJustify,
  Type as TypeIcon,
  Check,
  RotateCcw,
  Sun,
  Moon,
  Heart,
  Users,
  UserPlus,
  Shield,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  ChevronLeft,
  Utensils,
  TrendingUp,
  Map,
  User as UserIcon,
  GraduationCap,
  Search,
  ShoppingBag,
  Store,
  Compass,
  BookMarked,
  KeyRound
} from 'lucide-react';
import { cn } from './lib/utils';
import { TOP_NICHES, PROJECT_TEMPLATES, CHAPTER_TEMPLATES } from './constants';
import { Project, NicheOption, Chapter, ProjectTemplate, GrammarResult } from './types';
import { CartItem, CompletedOrder, StorefrontProduct } from './types/factory';
import { IconMap, GlobalLoadingBar, Button } from './components/Common';
import { CollaboratorsModal } from './components/CollaboratorsModal';
import { Storefront } from './components/Storefront';
import { NicheIntelligence } from './components/NicheIntelligence';
import { CommerceCheckout } from './components/CommerceCheckout';
import { MyLibrary } from './components/MyLibrary';
import { AccessDeniedView } from './components/AccessControl';
import { 
  generateEbookOutline, 
  generateChapterContent, 
  generateCoverArt, 
  checkGrammar, 
  translateChapter,
  generateChapterSummary,
  generateChapterImage,
  factCheckContent,
  analyzeTrendingNiches,
  researchTopic
} from './services/gemini';
import ReactMarkdown from 'react-markdown';


// --- Custom Extensions ---

const FontSize = Extension.create({
  name: 'fontSize',
  addOptions() {
    return {
      types: ['textStyle'],
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: element => element.style.fontSize,
            renderHTML: attributes => {
              if (!attributes.fontSize) return {};
              return { style: `font-size: ${attributes.fontSize}` };
            },
          },
        },
      },
    ];
  },
  addCommands() {
    return {
      setFontSize: (fontSize: string) => ({ chain }: any) => {
        return chain().setMark('textStyle', { fontSize }).run();
      },
      unsetFontSize: () => ({ chain }: any) => {
        return chain().setMark('textStyle', { fontSize: null }).removeEmptyTextStyle().run();
      },
    };
  },
});

const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ja', name: 'Japanese' },
  { code: 'zh', name: 'Chinese' },
  { code: 'ko', name: 'Korean' },
];

const TOC_TITLES: Record<string, string> = {
  en: "Table of Contents",
  es: "Índice",
  fr: "Table des matières",
  de: "Inhaltsverzeichnis",
  it: "Indice",
  pt: "Índice",
  ja: "目次",
  zh: "目录",
  ko: "목차"
};

const COVER_STYLES = [
  { id: "modern, minimalist", label: "Modern & Minimalist" },
  { id: "bold, vibrant, high-contrast", label: "Bold & Vibrant" },
  { id: "elegant, classic, serif typography", label: "Elegant & Classic" },
  { id: "futuristic, tech-inspired, neon accents", label: "Futuristic & Tech" },
  { id: "vintage, hand-drawn, retro illustration", label: "Vintage Illustration" },
  { id: "abstract, geometric shapes, mathematical precision", label: "Abstract Geometric" },
  { id: "photorealistic, cinematic landscape, high-detail", label: "Photorealistic Landscape" },
];

const CHAPTER_IMAGE_STYLES = [
  { id: "modern, minimalist, clean lines", label: "Minimalist" },
  { id: "detailed, realistic illustration, cinematic lighting", label: "Realistic" },
  { id: "sketch, hand-drawn, charcoal, pencil, artistic", label: "Sketch" },
  { id: "watercolor, artistic, soft colors, ethereal", label: "Watercolor" },
  { id: "digital art, vibrant, 3d render, octane render", label: "Digital Art" },
  { id: "vintage, retro, 1950s style, mid-century modern", label: "Vintage" },
  { id: "abstract, symbolic, metaphorical, conceptual", label: "Abstract" },
  { id: "oil painting, thick brushstrokes, classical", label: "Oil Painting" },
  { id: "cyberpunk, neon, futuristic, dark", label: "Cyberpunk" },
  { id: "fantasy, magical, whimsical, detailed", label: "Fantasy" },
  { id: "anime style, vibrant colors, expressive, cel-shaded", label: "Anime" },
  { id: "pop art, bold colors, comic book style, Lichtenstein inspired", label: "Pop Art" },
  { id: "isometric illustration, 3d perspective, clean, vector", label: "Isometric" },
  { id: "ukiyo-e, traditional japanese woodblock print style", label: "Ukiyo-e" },
  { id: "steampunk, victorian, brass, gears, industrial", label: "Steampunk" },
  { id: "low poly, geometric, 3d art, stylized", label: "Low Poly" },
];

// --- Components ---

const Card = ({ className, children }: any) => (
  <div className={cn("bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden", className)}>
    {children}
  </div>
);


const MenuBar = ({ 
  editor, 
  onDictate, 
  isDictating, 
  onGrammarCheck, 
  isCheckingGrammar, 
  onFactCheck, 
  isFactChecking, 
  onResearch,
  isResearching,
  onInsertImage, 
  isGeneratingImage, 
  imageStyle, 
  setImageStyle,
  wordCount
}: { 
  editor: any, 
  onDictate?: () => void, 
  isDictating?: boolean,
  onGrammarCheck?: () => void,
  isCheckingGrammar?: boolean,
  onFactCheck?: () => void,
  isFactChecking?: boolean,
  onResearch?: () => void,
  isResearching?: boolean,
  onInsertImage?: () => void,
  isGeneratingImage?: boolean,
  imageStyle?: string,
  setImageStyle?: (style: string) => void,
  wordCount?: number
}) => {
  if (!editor) return null;

  const fontSizes = ['12px', '14px', '16px', '18px', '20px', '24px', '30px'];

  return (
    <div className="flex flex-wrap gap-1 p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 sticky top-0 z-10">
      <div className="flex items-center gap-1 pr-1 border-r border-slate-200 dark:border-slate-800 mr-1">
        <button
          onClick={() => editor.chain().focus().undo().run()}
          disabled={!editor.can().chain().focus().undo().run()}
          className="p-2 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
          title="Undo"
        >
          <Undo className="w-4 h-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().redo().run()}
          disabled={!editor.can().chain().focus().redo().run()}
          className="p-2 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
          title="Redo"
        >
          <Redo className="w-4 h-4" />
        </button>
      </div>

      <button
        onClick={() => editor.chain().focus().toggleBold().run()}
        disabled={!editor.can().chain().focus().toggleBold().run()}
        className={cn("p-2 rounded hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors dark:text-slate-300", editor.isActive('bold') && "bg-slate-200 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400")}
        title="Bold"
        aria-label="Toggle Bold"
      >
        <Bold className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleItalic().run()}
        disabled={!editor.can().chain().focus().toggleItalic().run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('italic') && "bg-slate-200 text-indigo-600")}
        title="Italic"
        aria-label="Toggle Italic"
      >
        <Italic className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('underline') && "bg-slate-200 text-indigo-600")}
        title="Underline"
        aria-label="Toggle Underline"
      >
        <UnderlineIcon className="w-4 h-4" />
      </button>
      
      <div className="w-px h-6 bg-slate-200 mx-1 self-center" />
      
      <div className="flex items-center gap-1 bg-white border border-slate-200 rounded px-1">
        <TypeIcon className="w-3.5 h-3.5 text-slate-400 ml-1" aria-hidden="true" />
        <select 
          className="text-xs bg-transparent border-none focus:ring-0 py-1 pr-6"
          onChange={(e) => editor.chain().focus().setFontSize(e.target.value).run()}
          value={editor.getAttributes('textStyle').fontSize || '16px'}
          aria-label="Font Size"
        >
          {fontSizes.map(size => (
            <option key={size} value={size}>{size}</option>
          ))}
        </select>
      </div>

      <div className="w-px h-6 bg-slate-200 mx-1 self-center" />
      
      <button
        onClick={() => editor.chain().focus().setTextAlign('left').run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive({ textAlign: 'left' }) && "bg-slate-200 text-indigo-600")}
        title="Align Left"
        aria-label="Align Left"
      >
        <AlignLeft className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().setTextAlign('center').run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive({ textAlign: 'center' }) && "bg-slate-200 text-indigo-600")}
        title="Align Center"
        aria-label="Align Center"
      >
        <AlignCenter className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().setTextAlign('justify').run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive({ textAlign: 'justify' }) && "bg-slate-200 text-indigo-600")}
        title="Align Justify"
        aria-label="Align Justify"
      >
        <AlignJustify className="w-4 h-4" />
      </button>
      
      <div className="w-px h-6 bg-slate-200 mx-1 self-center" />
      
      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('heading', { level: 1 }) && "bg-slate-200 text-indigo-600")}
        title="Heading 1"
        aria-label="Heading 1"
      >
        <Heading1 className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('heading', { level: 2 }) && "bg-slate-200 text-indigo-600")}
        title="Heading 2"
        aria-label="Heading 2"
      >
        <Heading2 className="w-4 h-4" />
      </button>
      
      <div className="w-px h-6 bg-slate-200 mx-1 self-center" aria-hidden="true" />
      
      <button
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('bulletList') && "bg-slate-200 text-indigo-600")}
        title="Bullet List"
        aria-label="Bullet List"
      >
        <List className="w-4 h-4" />
      </button>
      <button
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={cn("p-2 rounded hover:bg-slate-200 transition-colors", editor.isActive('orderedList') && "bg-slate-200 text-indigo-600")}
        title="Ordered List"
        aria-label="Ordered List"
      >
        <ListOrdered className="w-4 h-4" />
      </button>
      
      <div className="w-px h-6 bg-slate-200 dark:bg-slate-800 mx-1 self-center" />
      
      <div className="flex items-center gap-0.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden shadow-sm">
        <div className="flex items-center px-2 border-r border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50">
          <Sparkles className="w-3 h-3 text-indigo-500 mr-1.5" aria-hidden="true" />
          <select 
            className="text-[10px] font-bold uppercase tracking-wider bg-transparent border-none focus:ring-0 py-1.5 pr-6 dark:text-slate-300 cursor-pointer"
            onChange={(e) => setImageStyle?.(e.target.value)}
            value={imageStyle}
            title="Select AI Image Style"
            aria-label="Select AI Image Style"
          >
            {CHAPTER_IMAGE_STYLES.map(style => (
              <option key={style.id} value={style.id}>{style.label}</option>
            ))}
          </select>
        </div>
        <button
          onClick={onInsertImage}
          disabled={isGeneratingImage}
          className={cn(
            "px-3 py-1.5 flex items-center gap-1.5 transition-all",
            isGeneratingImage 
              ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400" 
              : "hover:bg-indigo-600 hover:text-white text-indigo-600 dark:text-indigo-400"
          )}
          title="Generate and Insert AI Image"
          aria-label="Generate and Insert AI Image"
        >
          {isGeneratingImage ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ImageIcon className="w-3.5 h-3.5" />}
          <span className="text-[10px] font-bold uppercase tracking-wider hidden sm:inline">
            {isGeneratingImage ? "Generating..." : "Generate"}
          </span>
        </button>
      </div>
      
      <div className="w-px h-6 bg-slate-200 mx-1 self-center" />
      
      <button
        onClick={onDictate}
        className={cn(
          "p-2 rounded transition-all",
          isDictating ? "bg-red-100 text-red-600 animate-pulse" : "hover:bg-slate-200"
        )}
        title={isDictating ? "Stop Dictation" : "Start Dictation"}
      >
        <Mic className="w-4 h-4" />
      </button>
      <button
        onClick={onGrammarCheck}
        disabled={isCheckingGrammar}
        className={cn(
          "px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 text-xs font-medium",
          isCheckingGrammar 
            ? "bg-indigo-100 text-indigo-600" 
            : "bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-200 hover:bg-slate-50"
        )}
        title="Check Grammar & Style"
      >
        {isCheckingGrammar ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Languages className="w-3.5 h-3.5" />}
        Check Grammar
      </button>

      <button
        onClick={onFactCheck}
        disabled={isFactChecking}
        className={cn(
          "px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 text-xs font-medium",
          isFactChecking 
            ? "bg-indigo-100 text-indigo-600" 
            : "bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-200 hover:bg-slate-50"
        )}
        title="AI Fact-Check Content"
      >
        {isFactChecking ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />}
        Fact-Check
      </button>

      <button
        onClick={onResearch}
        disabled={isResearching}
        className={cn(
          "px-3 py-1.5 rounded-lg transition-all flex items-center gap-2 text-xs font-medium",
          isResearching 
            ? "bg-indigo-100 text-indigo-600" 
            : "bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-200 hover:bg-slate-50"
        )}
        title="AI Research Topic"
      >
        {isResearching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5 text-indigo-600" />}
        Researcher
      </button>

      {wordCount !== undefined && (
        <div className="ml-auto flex items-center gap-1 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-500 dark:text-slate-400">
          <FileText className="w-3.5 h-3.5" />
          <span className="text-[11px] font-bold tracking-tight">{wordCount} words</span>
        </div>
      )}
    </div>
  );
};

const ChapterGallery = ({ images, onInsert, onDelete }: { 
  images: string[], 
  onInsert: (url: string) => void,
  onDelete: (url: string) => void
}) => {
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  if (!images || images.length === 0) return null;

  return (
    <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-800">
      <div className="flex items-center gap-2 mb-4">
        <ImageIcon className="w-5 h-5 text-indigo-600" />
        <h3 className="font-bold text-lg dark:text-white">Image Gallery</h3>
        <span className="text-xs text-slate-500 dark:text-slate-400 font-normal">({images.length} generated)</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {images.map((url, idx) => (
          <div key={idx} className="group relative aspect-video bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
            <img 
              src={url} 
              alt={`AI Generated ${idx}`} 
              className="w-full h-full object-cover transition-transform group-hover:scale-105 cursor-pointer"
              referrerPolicy="no-referrer"
              onClick={() => setZoomedImage(url)}
            />
            <div className="absolute top-2 right-2 flex gap-1 transform translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-200">
              <button 
                onClick={() => setZoomedImage(url)}
                className="p-1.5 bg-white/90 text-slate-700 rounded-md hover:bg-white shadow-sm transition-colors"
                title="Zoom image"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 pointer-events-none group-hover:pointer-events-auto">
              <button 
                onClick={(e) => { e.stopPropagation(); onInsert(url); }}
                className="p-2 bg-white text-slate-900 rounded-full hover:bg-indigo-600 hover:text-white transition-colors"
                title="Insert into chapter"
                aria-label="Insert image into chapter"
              >
                <Plus className="w-4 h-4" />
              </button>
              <button 
                onClick={(e) => { e.stopPropagation(); onDelete(url); }}
                className="p-2 bg-white text-red-600 rounded-full hover:bg-red-600 hover:text-white transition-colors"
                title="Delete image"
                aria-label="Delete image"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {zoomedImage && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 animate-in fade-in duration-200"
          onClick={() => setZoomedImage(null)}
        >
          <div className="relative max-w-5xl w-full max-h-[90vh] flex flex-col items-center animate-in zoom-in-95 duration-200">
            <button 
              className="absolute -top-12 right-0 p-2 text-white hover:text-slate-300 transition-colors"
              onClick={() => setZoomedImage(null)}
            >
              <X className="w-8 h-8" />
            </button>
            <img 
              src={zoomedImage} 
              alt="Zoomed AI Artwork" 
              className="w-full h-full object-contain rounded-lg shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="mt-4 flex gap-4">
              <Button 
                onClick={() => { onInsert(zoomedImage); setZoomedImage(null); }}
                className="bg-indigo-600 text-white"
              >
                Insert into Chapter
              </Button>
              <Button 
                onClick={() => setZoomedImage(null)}
                className="bg-white/10 text-white hover:bg-white/20"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const FactCheckResults = ({ results, onClose, onHighlight }: { results: any[], onClose: () => void, onHighlight?: (text: string) => void }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 w-full max-w-3xl flex flex-col max-h-[85vh]">
        <div className="bg-slate-50 dark:bg-slate-800/50 p-5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-gradient-to-r from-slate-50 to-white dark:from-slate-800/50 dark:to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white">Advanced Fact-Check Analysis</h3>
              <p className="text-xs text-slate-500 font-medium">Detailed report on factual accuracy and claims</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors group">
            <X className="w-6 h-6 text-slate-400 group-hover:text-slate-600" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          {results.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-emerald-500" />
              </div>
              <h4 className="font-bold text-slate-900 dark:text-white mb-2">Everything looks correct!</h4>
              <p className="text-sm text-slate-500 max-w-xs mx-auto">Our AI couldn't find any major factual claims to flag in this chapter.</p>
            </div>
          ) : (
            results.map((item, idx) => (
              <div key={idx} className={cn(
                "p-5 rounded-2xl border transition-all duration-200 group relative shadow-sm",
                item.status === 'accurate' ? "bg-emerald-50/30 border-emerald-100 hover:bg-emerald-50 dark:bg-emerald-900/5 dark:border-emerald-900/20" :
                item.status === 'inaccurate' ? "bg-red-50/30 border-red-100 hover:bg-red-50 dark:bg-red-900/5 dark:border-red-900/20" :
                "bg-amber-50/30 border-amber-100 hover:bg-amber-50 dark:bg-amber-900/5 dark:border-amber-900/20"
              )}>
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 pr-6">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1 block">Claim Analyzed</span>
                    <h4 className="font-bold text-base text-slate-900 dark:text-white leading-tight">"{item.claim}"</h4>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <div className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm",
                      item.status === 'accurate' ? "bg-emerald-500 text-white" :
                      item.status === 'inaccurate' ? "bg-red-500 text-white" :
                      "bg-amber-500 text-white"
                    )}>
                      {item.status.replace('_', ' ')}
                    </div>
                    {onHighlight && (
                      <button 
                        onClick={() => { onHighlight(item.claim); onClose(); }}
                        className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        Find in text
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="bg-white/60 dark:bg-slate-800/40 rounded-xl p-4 mb-4 border border-white dark:border-slate-800">
                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {item.evidence}
                  </p>
                </div>

                <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3">
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Confidence</span>
                      <div className="flex items-center gap-1.5 font-bold text-xs">
                        <div className="w-16 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full rounded-full transition-all duration-1000",
                              item.confidence > 80 ? "bg-emerald-500" : item.confidence > 50 ? "bg-amber-500" : "bg-red-500"
                            )}
                            style={{ width: `${item.confidence}%` }}
                          />
                        </div>
                        <span className={cn(
                          item.confidence > 80 ? "text-emerald-600" : item.confidence > 50 ? "text-amber-600" : "text-red-600"
                        )}>{item.confidence}%</span>
                      </div>
                    </div>
                  </div>
                  {item.sources && item.sources.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {item.sources.slice(0, 3).map((url: string, sIdx: number) => (
                        <a 
                          key={sIdx} 
                          href={url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 transition-all flex items-center gap-2 font-bold shadow-sm group/link active:scale-95"
                        >
                          <ExternalLink className="w-3 h-3" />
                          Source {sIdx + 1}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
        <div className="p-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex justify-end">
          <Button onClick={onClose} className="bg-slate-900 text-white px-6">Close Report</Button>
        </div>
      </div>
    </div>
  );
};

const FactCheckSummary = ({ results, onShowDetails }: { results: any[], onShowDetails: () => void }) => {
  const accurate = results.filter(r => r.status === 'accurate').length;
  const inaccurate = results.filter(r => r.status === 'inaccurate').length;
  const partial = results.filter(r => r.status === 'partially_accurate').length;

  const hasIssues = inaccurate > 0 || partial > 0;

  return (
    <div className={cn(
      "border rounded-xl p-4 flex items-center justify-between mb-6 shadow-sm animate-in fade-in slide-in-from-top-2",
      hasIssues 
        ? "bg-amber-50 border-amber-200 dark:bg-amber-900/10 dark:border-amber-900/30" 
        : "bg-emerald-50 border-emerald-200 dark:bg-emerald-900/10 dark:border-emerald-900/30"
    )}>
      <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
        <div className="flex items-center gap-3">
          <div className={cn(
            "p-2 rounded-full",
            hasIssues ? "bg-amber-100 text-amber-600" : "bg-emerald-100 text-emerald-600"
          )}>
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <h4 className={cn(
              "text-sm font-bold uppercase tracking-wider",
              hasIssues ? "text-amber-900 dark:text-amber-400" : "text-emerald-900 dark:text-emerald-400"
            )}>
              AI Fact-Check Results
            </h4>
            <div className="flex items-center gap-2">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {results.length} claims found
              </p>
              {hasIssues && (
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-slate-300" />
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-bold text-red-600 bg-red-100 px-1.5 py-0.5 rounded">
                      {inaccurate} inaccuracies
                    </span>
                    {partial > 0 && (
                      <span className="text-[10px] font-bold text-amber-600 bg-amber-100 px-1.5 py-0.5 rounded">
                        {partial} partial
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
            {hasIssues && (
              <div className="mt-1.5 flex flex-wrap gap-2">
                {results.filter(r => r.status === 'inaccurate' || r.status === 'partially_accurate').slice(0, 2).map((r, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-[10px] text-slate-600 dark:text-slate-400 italic bg-white/40 dark:bg-slate-800/40 px-2 py-0.5 rounded border border-slate-200/50 dark:border-slate-700/50">
                    <div className={cn("w-1.5 h-1.5 rounded-full", r.status === 'inaccurate' ? "bg-red-500" : "bg-amber-500")} />
                    <span className="truncate max-w-[200px]">"{r.claim}"</span>
                  </div>
                ))}
                {(inaccurate + partial) > 2 && (
                  <span className="text-[10px] text-slate-400 font-medium">+{inaccurate + partial - 2} more issues</span>
                )}
              </div>
            )}
          </div>
        </div>
        <div className="flex gap-8">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Accurate</span>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{accurate}</span>
            </div>
          </div>
          {partial > 0 && (
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Partial</span>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{partial}</span>
              </div>
            </div>
          )}
          {inaccurate > 0 && (
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Inaccurate</span>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{inaccurate}</span>
              </div>
            </div>
          )}
        </div>
      </div>
      <button 
        onClick={onShowDetails}
        className={cn(
          "px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-sm",
          hasIssues 
            ? "bg-amber-600 text-white hover:bg-amber-700" 
            : "bg-emerald-600 text-white hover:bg-emerald-700"
        )}
      >
        View Full Report <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};

const FactCheckHighlight = Extension.create({
  name: 'factCheckHighlight',

  addOptions() {
    return {
      claims: [] as any[],
    };
  },

  addCommands() {
    return {
      updateFactCheckClaims: (claims: any[]) => ({ editor }: { editor: any }) => {
        this.options.claims = claims;
        return true;
      },
    } as any;
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        props: {
          decorations: (state) => {
            const { doc } = state;
            const decorations: Decoration[] = [];
            const claims = this.options.claims;

            if (!claims || claims.length === 0) return DecorationSet.empty;

            doc.descendants((node, pos) => {
              if (node.isText && node.text) {
                claims.forEach((item) => {
                  const claim = item.claim;
                  let index = node.text!.indexOf(claim);
                  while (index !== -1) {
                    const start = pos + index;
                    const end = start + claim.length;
                    
                    let className = 'fact-check-highlight cursor-help transition-colors hover:bg-opacity-80 ';
                    if (item.status === 'accurate') className += 'bg-emerald-100/50 border-b-[3px] border-emerald-400';
                    else if (item.status === 'inaccurate') className += 'bg-red-100/50 border-b-[3px] border-red-400';
                    else if (item.status === 'partially_accurate') className += 'bg-amber-100/50 border-b-[3px] border-amber-400';
                    else className += 'bg-slate-100/50 border-b-[3px] border-slate-400';

                    decorations.push(
                      Decoration.inline(start, end, {
                        class: className,
                        title: `${item.status.replace('_', ' ')}: ${item.evidence.substring(0, 100)}...`,
                      })
                    );
                    index = node.text!.indexOf(claim, index + 1);
                  }
                });
              }
            });

            return DecorationSet.create(doc, decorations);
          },
        },
      }),
    ];
  },
});

const ChapterContent = ({ chapter, projectId, niche, tone, setError, onWordCountUpdate, onToggleReview, selectedLanguage = 'en' }: { 
  chapter: Chapter, 
  projectId: string, 
  niche?: string,
  tone?: string,
  setError: (msg: string | null) => void, 
  onWordCountUpdate?: (count: number) => void,
  onToggleReview?: (chapterId: string, isReviewed: boolean) => void,
  selectedLanguage?: string
}) => {
  const [content, setContent] = useState<string>("");
  const [summary, setSummary] = useState<string>(chapter.summary || "");
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDictating, setIsDictating] = useState(false);
  const [isCheckingGrammar, setIsCheckingGrammar] = useState(false);
  const [suggestion, setSuggestion] = useState<GrammarResult | null>(null);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [imageStyle, setImageStyle] = useState<string>("modern, minimalist");
  const [isFactChecking, setIsFactChecking] = useState(false);
  const [isResearching, setIsResearching] = useState(false);
  const [showResearchPrompt, setShowResearchPrompt] = useState(false);
  const [researchQuery, setResearchQuery] = useState("");
  const [researchResult, setResearchResult] = useState<string | null>(null);
  const [factCheckResults, setFactCheckResults] = useState<any[] | null>(chapter.factCheck?.claims || null);
  const [showFactCheckDetails, setShowFactCheckDetails] = useState(false);
  const [viewMode, setViewMode] = useState<'rich' | 'markdown'>('rich');
  const [wordCount, setWordCount] = useState(0);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    setFactCheckResults(chapter.factCheck?.claims || null);
  }, [chapter.factCheck]);

  useEffect(() => {
    setSummary(chapter.summary || "");
  }, [chapter.summary]);

  const calculateWordCount = (text: string) => {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  };

  const handleFactCheck = async () => {
    if (!editor) return;
    const markdown = (editor.storage as any).markdown.getMarkdown();
    if (!markdown || markdown.length < 50) {
      toast.error("Content is too short for fact-checking.");
      return;
    }

    setIsFactChecking(true);
    setShowFactCheckDetails(false);
    try {
      const results = await factCheckContent(markdown, niche, tone);
      setFactCheckResults(results.claims);
      
      // Save results to Firestore
      if (chapter.id && projectId) {
        await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id), {
          factCheck: {
            lastCheckedAt: serverTimestamp(),
            claims: results.claims
          },
          updatedAt: serverTimestamp()
        });
      }

      if (results.claims.length === 0) {
        toast.info("No major factual claims identified for verification.");
      } else {
        toast.success(`Fact-check complete! ${results.claims.length} claims analyzed.`);
        setShowFactCheckDetails(true);
      }
    } catch (err) {
      handleAIError(err, "Fact-check");
    } finally {
      setIsFactChecking(false);
    }
  };

  const handleResearch = async () => {
    if (!researchQuery) return;
    setShowResearchPrompt(false);
    setIsResearching(true);
    toast.info(`Researching: "${researchQuery}" using Google Search...`);
    try {
      const result = await researchTopic(researchQuery);
      setResearchResult(result);
      toast.success("Research summary generated!");
      setResearchQuery("");
    } catch (err) {
      handleAIError(err, "Research");
    } finally {
      setIsResearching(false);
    }
  };

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      TextStyle,
      FontSize,
      Link.configure({
        openOnClick: false,
      }),
      Placeholder.configure({
        placeholder: 'Write your chapter content here...',
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Image.configure({
        HTMLAttributes: {
          class: 'rounded-xl shadow-lg my-8 mx-auto block max-w-full',
        },
      }),
      Markdown,
      FactCheckHighlight.configure({
        claims: factCheckResults || [],
      }),
    ],
    content: '',
    editable: isEditing,
    editorProps: {
      attributes: {
        class: 'prose prose-slate max-w-none focus:outline-none min-h-[200px] p-4',
        spellcheck: 'true',
      },
    },
    onUpdate: ({ editor }) => {
      const markdown = (editor.storage as any).markdown.getMarkdown();
      const count = calculateWordCount(markdown);
      setWordCount(count);
      onWordCountUpdate?.(count);
    }
  });

  useEffect(() => {
    if (editor && factCheckResults) {
      (editor.commands as any).updateFactCheckClaims(factCheckResults);
      // Force re-render of decorations
      editor.view.dispatch(editor.state.tr);
    }
  }, [editor, factCheckResults]);

  const handleDictation = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Speech recognition is not supported in this browser.");
      return;
    }

    if (isDictating) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsDictating(false);
      return;
    }

    // Ensure we are in editing mode when starting dictation
    if (!isEditing) {
      setIsEditing(true);
    }

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = selectedLanguage === 'en' ? 'en-US' : selectedLanguage;

    recognition.onstart = () => {
      setIsDictating(true);
      toast.success("Listening...");
    };

    recognition.onresult = (event: any) => {
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        }
      }

      if (finalTranscript && editor) {
        editor.commands.insertContent(finalTranscript + ' ');
      }
    };

    recognition.onerror = (event: any) => {
      if (event.error === 'no-speech') return;
      console.error("Speech recognition error:", event.error);
      setIsDictating(false);
      toast.error(`Speech recognition error: ${event.error}`);
    };

    recognition.onend = () => {
      setIsDictating(false);
      recognitionRef.current = null;
    };

    recognition.start();
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const handleGrammarCheck = async () => {
    if (!editor) return;
    const currentText = (editor.storage as any).markdown.getMarkdown();
    if (!currentText.trim()) return;

    setIsCheckingGrammar(true);
    setSuggestion(null);
    toast.info("Checking grammar and style...");
    try {
      const result = await checkGrammar(currentText);
      if (result && result.improvedText !== currentText) {
        setSuggestion(result);
        toast.success("Grammar and style improvements suggested!");
      } else {
        toast.success("Your text looks great!");
      }
    } catch (err) {
      handleAIError(err, "Grammar check");
    } finally {
      setIsCheckingGrammar(false);
    }
  };

  const acceptSuggestion = () => {
    if (editor && suggestion) {
      editor.commands.setContent(suggestion.improvedText);
      setSuggestion(null);
      toast.success("Suggestion applied!");
    }
  };

  const discardSuggestion = () => {
    setSuggestion(null);
  };

  const handleGenerateSummary = async () => {
    if (!editor) return;
    const currentText = (editor.storage as any).markdown.getMarkdown();
    if (!currentText.trim()) return;

    setIsGeneratingSummary(true);
    toast.info("Generating chapter summary...");
    try {
      const generatedSummary = await generateChapterSummary(chapter.title, currentText);
      if (generatedSummary) {
        setSummary(generatedSummary);
        // Save summary to Firestore
        if (selectedLanguage === 'en') {
          await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id!), {
            summary: generatedSummary,
            updatedAt: serverTimestamp()
          });
        } else {
          const translations = { ...(chapter.translations || {}) };
          translations[selectedLanguage] = {
            ...translations[selectedLanguage],
            summary: generatedSummary
          };
          await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id!), {
            translations,
            updatedAt: serverTimestamp()
          });
        }
        toast.success("Summary generated!");
      }
    } catch (err) {
      handleAIError(err, "Summary generation");
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const handleInsertAIImage = async () => {
    if (!editor) return;
    setIsGeneratingImage(true);
    const styleLabel = CHAPTER_IMAGE_STYLES.find(s => s.id === imageStyle)?.label || 'AI';
    toast.info(`Generating ${styleLabel} image...`);
    
    try {
      const generatedUrl = await generateChapterImage(chapter.title, chapter.title, imageStyle);
      
      if (generatedUrl) {
        // We MUST upload it to Storage to avoid the 1MB Firestore doc limit and keep the document clean
        const storageRef = ref(storage, `projects/${projectId}/chapters/${chapter.id}/images/img_${Date.now()}.png`);
        await uploadString(storageRef, generatedUrl, 'data_url');
        const imageUrl = await getDownloadURL(storageRef);

        editor.chain().focus().setImage({ src: imageUrl }).run();
        
        // Save to chapter's image gallery in Firestore
        if (chapter.id) {
          try {
            await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id), {
              images: arrayUnion(imageUrl),
              updatedAt: serverTimestamp()
            });
          } catch (dbErr) {
            console.error("Failed to save image to gallery:", dbErr);
          }
        }
        
        toast.success("AI image inserted!");
      } else {
        toast.error("The AI was unable to generate an image for this content. Try a different style or keywords.");
      }
    } catch (err: any) {
      handleAIError(err, "Image generation");
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleReinsertImage = (url: string) => {
    if (editor) {
      editor.chain().focus().setImage({ src: url }).run();
      toast.success("Image re-inserted!");
    }
  };

  const handleDeleteImage = async (url: string) => {
    if (!chapter.id || !projectId) return;
    
    try {
      await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id), {
        images: arrayRemove(url),
        updatedAt: serverTimestamp()
      });
      toast.success("Image removed from gallery");
    } catch (err) {
      console.error("Failed to delete image:", err);
      toast.error("Failed to delete image");
    }
  };

  const currentContentUrl = selectedLanguage === 'en' 
    ? chapter.contentUrl 
    : chapter.translations?.[selectedLanguage]?.contentUrl;

  const currentSummary = selectedLanguage === 'en'
    ? summary
    : chapter.translations?.[selectedLanguage]?.summary;

  useEffect(() => {
    const fetchContent = async () => {
      if (!currentContentUrl) {
        setContent("");
        if (editor) editor.commands.setContent("");
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        if (!navigator.onLine) {
          throw new Error("Network is offline");
        }
        const response = await fetch(currentContentUrl);
        const text = await response.text();
        setContent(text);
        const count = calculateWordCount(text);
        setWordCount(count);
        onWordCountUpdate?.(count);
        if (editor) {
          editor.commands.setContent(text);
        }
        // Cache the newly fetched content to IndexedDB for offline access
        if (chapter.id && projectId) {
          cacheChapter(projectId, chapter, text, false).catch((err) =>
            console.warn("Could not cache chapter content:", err)
          );
        }
      } catch (err) {
        console.warn("Failed to fetch chapter content from remote URL, trying local IndexedDB cache:", err);
        if (chapter.id) {
          try {
            const cached = await getCachedChapter(chapter.id);
            if (cached && cached.localContent) {
              setContent(cached.localContent);
              const count = calculateWordCount(cached.localContent);
              setWordCount(count);
              onWordCountUpdate?.(count);
              if (editor) {
                editor.commands.setContent(cached.localContent);
              }
              toast.info("Loaded cached chapter copy offline.");
            } else {
              setError("This chapter is not cached for offline access yet.");
            }
          } catch (cacheErr) {
            console.error("Failed to read from IndexedDB:", cacheErr);
            setError("Failed to load chapter offline.");
          }
        }
      } finally {
        setLoading(false);
      }
    };
    fetchContent();
  }, [currentContentUrl, editor, chapter.id]);

  useEffect(() => {
    if (editor) {
      editor.setEditable(isEditing);
    }
  }, [isEditing, editor]);

  const handleSave = async () => {
    if (!editor || !projectId || !chapter.id) return;
    setIsSaving(true);
    try {
      const markdownContent = (editor.storage as any).markdown.getMarkdown();
      
      const fileName = selectedLanguage === 'en' 
        ? `chapter_${chapter.index}.md` 
        : `chapter_${chapter.index}_${selectedLanguage}.md`;

      // Save to IndexedDB cache optimistically so that even before syncing, the editor loads it
      await cacheChapter(projectId, chapter, markdownContent, !navigator.onLine);

      if (!navigator.onLine) {
        throw new Error("Offline");
      }

      const storageRef = ref(storage, `projects/${projectId}/chapters/${fileName}`);
      await uploadString(storageRef, markdownContent);
      const contentUrl = await getDownloadURL(storageRef);
      
      if (selectedLanguage === 'en') {
        await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id!), {
          contentUrl,
          updatedAt: serverTimestamp()
        });
      } else {
        const translations = { ...(chapter.translations || {}) };
        translations[selectedLanguage] = {
          ...translations[selectedLanguage],
          contentUrl
        };
        await updateDoc(doc(db, 'projects', projectId, 'chapters', chapter.id!), {
          translations,
          updatedAt: serverTimestamp()
        });
      }
      
      setIsEditing(false);
      setContent(markdownContent);
      toast.success("Chapter saved successfully!");
    } catch (err) {
      const isOfflineErr = !navigator.onLine || (err instanceof Error && err.message.includes("Offline"));
      if (isOfflineErr) {
        const markdownContent = (editor.storage as any).markdown.getMarkdown();
        try {
          await queueOfflineAction({
            type: 'save-chapter',
            projectId,
            chapterId: chapter.id,
            data: { 
              content: markdownContent, 
              index: chapter.index, 
              language: selectedLanguage 
            }
          });
          setIsEditing(false);
          setContent(markdownContent);
          toast.success("Draft saved offline! It will sync automatically when you reconnect.");
        } catch (queueErr) {
          console.error("Failed to queue offline action:", queueErr);
          setError("Failed to save offline.");
        }
      } else {
        console.error("Failed to save chapter content:", err);
        setError("Failed to save content. Please try again.");
      }
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) return <div className="animate-pulse h-24 bg-slate-100 rounded-lg" />;

  if (!currentContentUrl && selectedLanguage !== 'en') {
    return (
      <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
        <Languages className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-sm text-slate-500">This chapter has not been translated into this language yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {currentSummary && (
        <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Chapter Summary</h4>
          </div>
          <p className="text-sm text-slate-600 italic leading-relaxed">"{currentSummary}"</p>
        </div>
      )}

      {factCheckResults && (
        <FactCheckSummary 
          results={factCheckResults} 
          onShowDetails={() => setShowFactCheckDetails(true)} 
        />
      )}

      {factCheckResults && showFactCheckDetails && (
        <FactCheckResults 
          results={factCheckResults} 
          onClose={() => setShowFactCheckDetails(false)} 
          onHighlight={(claim) => {
            if (!editor) return;
            const { state } = editor;
            const { doc } = state;
            let found = false;
            doc.descendants((node, pos) => {
              if (node.isText && node.text?.includes(claim)) {
                const start = pos + node.text.indexOf(claim);
                const end = start + claim.length;
                editor.commands.setTextSelection({ from: start, to: end });
                editor.commands.scrollIntoView();
                found = true;
                return false;
              }
            });
            if (!found) {
              toast.error("Could not find this claim in the current text.");
            }
          }}
        />
      )}

      {showResearchPrompt && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-5 mb-6 shadow-sm animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold text-indigo-900 pb-2 w-full flex items-center gap-2 m-0 p-0">
              <Search className="w-5 h-5 text-indigo-600" /> Topic Web Research
            </h4>
            <button onClick={() => setShowResearchPrompt(false)} className="p-1 hover:bg-indigo-100 rounded-lg text-indigo-400 hover:text-indigo-600 -mt-2">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-3">
            <label className="text-xs font-semibold text-slate-700">What would you like to research?</label>
            <input 
              type="text" 
              value={researchQuery} 
              onChange={e => setResearchQuery(e.target.value)} 
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g. History of the Byzantine Empire"
              autoFocus
              onKeyDown={e => {
                if (e.key === 'Enter') handleResearch();
                if (e.key === 'Escape') setShowResearchPrompt(false);
              }}
            />
            <div className="flex justify-end pt-2">
              <Button onClick={handleResearch} disabled={!researchQuery.trim()} className="bg-indigo-600 text-white text-xs py-1.5 px-4 h-8">
                Search Web
              </Button>
            </div>
          </div>
        </div>
      )}

      {suggestion && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-6 shadow-sm animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-amber-900">AI Grammar & Style Analysis</h4>
                <p className="text-[10px] text-amber-700 font-medium">{suggestion.suggestions.length} improvements suggested</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={discardSuggestion}
                className="text-xs font-bold text-slate-500 hover:text-slate-700 px-3 py-1.5 rounded-lg hover:bg-white/50 transition-colors flex items-center gap-1.5"
              >
                <X className="w-3.5 h-3.5" />
                Discard
              </button>
              <button 
                onClick={acceptSuggestion}
                className="text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 px-4 py-1.5 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                Accept All Changes
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-amber-800 uppercase tracking-widest px-1">Specific Suggestions</label>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                {suggestion.suggestions.map((s, idx) => (
                  <div key={idx} className="bg-white/60 rounded-lg p-3 border border-amber-100/50 hover:bg-white transition-colors group">
                    <div className="flex items-start gap-2 mb-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 flex-shrink-0" />
                      <p className="text-xs font-medium text-amber-900 leading-relaxed">{s.explanation}</p>
                    </div>
                    <div className="pl-3.5 space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-red-400 uppercase w-12 flex-shrink-0">From</span>
                        <span className="text-[11px] text-slate-500 line-through decoration-red-300 decoration-1 bg-red-50/30 px-1 rounded">{s.original}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-emerald-500 uppercase w-12 flex-shrink-0">To</span>
                        <span className="text-[11px] text-slate-700 font-medium bg-emerald-50/30 px-1 rounded">{s.improved}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex flex-col">
              <label className="text-[10px] font-bold text-amber-800 uppercase tracking-widest px-1 mb-3">Improved Draft</label>
              <div className="flex-1 bg-white/90 rounded-lg p-4 border border-amber-100 max-h-60 overflow-y-auto text-sm text-slate-700 leading-relaxed font-serif italic relative">
                <div className="absolute top-2 right-2 opacity-10">
                  <Quote className="w-8 h-8 text-amber-900" />
                </div>
                {suggestion.improvedText}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center bg-slate-50/50 p-2 rounded-lg border border-slate-100">
        <div className="flex items-center gap-4">
          <div className="flex p-0.5 bg-white border border-slate-200 rounded-lg shadow-sm">
            <button 
              onClick={() => setViewMode('rich')}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                viewMode === 'rich' ? "bg-slate-900 text-white shadow-md shadow-slate-200" : "text-slate-400 hover:text-slate-600"
              )}
            >
              <Layout className="w-3 h-3" />
              Editor
            </button>
            <button 
              onClick={() => setViewMode('markdown')}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                viewMode === 'markdown' ? "bg-slate-900 text-white shadow-md shadow-slate-200" : "text-slate-400 hover:text-slate-600"
              )}
            >
              <FileCode className="w-3 h-3" />
              Markdown
            </button>
          </div>

          <div className="w-px h-4 bg-slate-200" />

          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2">
            {isEditing ? "Editing Mode" : "Read-Only Mode"}
          </span>
          <div className="flex items-center gap-1 text-slate-400">
            <FileText className="w-3 h-3" />
            <span className="text-xs font-bold">{wordCount} words</span>
          </div>
          {factCheckResults && (
            <button 
              onClick={() => setShowFactCheckDetails(true)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all hover:scale-105 active:scale-95",
                factCheckResults.some(c => c.status === 'inaccurate') ? "bg-red-100 text-red-600 hover:bg-red-200" :
                factCheckResults.some(c => c.status === 'partially_accurate') ? "bg-amber-100 text-amber-600 hover:bg-amber-200" :
                "bg-emerald-100 text-emerald-600 hover:bg-emerald-200"
              )}
            >
              <ShieldCheck className="w-3 h-3" />
              {factCheckResults.some(c => c.status === 'inaccurate') ? "Factual Issues" :
               factCheckResults.some(c => c.status === 'partially_accurate') ? "Partial Review" :
               "Content Verified"}
              <Maximize2 className="ml-1 w-2.5 h-2.5 opacity-50" />
            </button>
          )}
        </div>
        <div className="flex gap-2">
          {(!isEditing || viewMode === 'markdown') && (
            <Button 
              onClick={handleSave}
              disabled={isSaving}
              className="bg-indigo-600 text-white py-1 px-4 text-sm h-9 shadow-lg shadow-indigo-100 hover:shadow-indigo-200 transition-all active:scale-95"
            >
              {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              Save Chapter
            </Button>
          )}
          <Button 
            onClick={handleFactCheck}
            disabled={isFactChecking}
            className={cn(
              "bg-white border border-slate-200 text-slate-600 py-1 px-3 text-sm h-9 hover:text-indigo-600 hover:border-indigo-200",
              isFactChecking && "text-indigo-600 border-indigo-200 bg-indigo-50"
            )}
            title="Verify factual claims using AI"
          >
            {isFactChecking ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
            Fact-Check
          </Button>
          <Button 
            onClick={handleDictation}
            className={cn(
              "bg-white border border-slate-200 text-slate-600 py-1 px-3 text-sm h-9 hover:text-red-600 hover:border-red-200",
              isDictating && "text-red-600 border-red-200 bg-red-50 animate-pulse"
            )}
            title={isDictating ? "Stop listening" : "Start voice dictation"}
          >
            <Mic className="w-3.5 h-3.5" />
            {isDictating ? "Listening..." : "Dictate"}
          </Button>
          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2 h-8">
            <Sparkles className="w-3 h-3 text-indigo-500" />
            <select 
              className="text-[10px] font-bold uppercase tracking-wider bg-transparent border-none focus:ring-0 py-0 pr-6 cursor-pointer"
              onChange={(e) => setImageStyle(e.target.value)}
              value={imageStyle}
            >
              {CHAPTER_IMAGE_STYLES.map(style => (
                <option key={style.id} value={style.id}>{style.label}</option>
              ))}
            </select>
            <Button 
              onClick={handleInsertAIImage}
              disabled={isGeneratingImage || !isEditing}
              className="bg-indigo-600 text-white py-0 px-2 text-[10px] h-6 rounded"
            >
              {isGeneratingImage ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : "Generate Image"}
            </Button>
          </div>
          <Button 
            onClick={handleGrammarCheck}
            disabled={isCheckingGrammar || !isEditing}
            className={cn(
              "bg-white border border-slate-200 text-slate-600 py-1 px-3 text-sm h-8 hover:text-indigo-600 hover:border-indigo-200",
              isCheckingGrammar && "text-indigo-600 border-indigo-200 bg-indigo-50"
            )}
            title="Check grammar and style improvements"
          >
            {isCheckingGrammar ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Languages className="w-3.5 h-3.5" />}
            Check Grammar
          </Button>
          <Button 
            onClick={handleGenerateSummary}
            disabled={isGeneratingSummary || isEditing}
            className="bg-white border border-slate-200 text-slate-600 py-1 px-3 text-sm h-8 hover:text-indigo-600 hover:border-indigo-200"
          >
            {isGeneratingSummary ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {currentSummary ? "Regenerate Summary" : "Generate Summary"}
          </Button>
          <label className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
            <input 
              id={`review-toggle-${chapter.id}`}
              type="checkbox" 
              checked={chapter.isReviewed || false} 
              onChange={() => onToggleReview?.(chapter.id!, chapter.isReviewed || false)}
              className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
            />
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Reviewed</span>
          </label>
          {isEditing ? (
            <>
              <Button 
                onClick={() => {
                  setIsEditing(false);
                  editor?.commands.setContent(content);
                }}
                className="bg-white border border-slate-200 text-slate-600 py-1 px-3 text-sm h-8"
              >
                <X className="w-3.5 h-3.5" />
                Cancel
              </Button>
              <Button 
                onClick={handleSave}
                disabled={isSaving}
                className="bg-indigo-600 text-white py-1 px-3 text-sm h-8"
              >
                {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                Save Chapter
              </Button>
            </>
          ) : (
            <Button 
              onClick={() => setIsEditing(true)}
              className="bg-indigo-50 text-indigo-600 py-1 px-3 text-sm h-8 hover:bg-indigo-100"
            >
              <Edit2 className="w-3.5 h-3.5" />
              Edit Content
            </Button>
          )}
        </div>
      </div>

      <div className={cn(
        "rounded-xl border transition-all duration-300",
        isEditing ? "border-indigo-200 ring-4 ring-indigo-50 shadow-lg bg-white" : "border-slate-200 bg-slate-50/30"
      )}>
        {isEditing && (
          <MenuBar 
            editor={editor} 
            onDictate={handleDictation} 
            isDictating={isDictating}
            onGrammarCheck={handleGrammarCheck}
            isCheckingGrammar={isCheckingGrammar}
            onFactCheck={handleFactCheck}
            isFactChecking={isFactChecking}
            onResearch={() => {
              setResearchQuery(chapter.title);
              setShowResearchPrompt(true);
            }}
            isResearching={isResearching}
            onInsertImage={handleInsertAIImage}
            isGeneratingImage={isGeneratingImage}
            imageStyle={imageStyle}
            setImageStyle={setImageStyle}
            wordCount={wordCount}
          />
        )}
          {viewMode === 'rich' ? (
            <EditorContent editor={editor} />
          ) : (
            <div className="p-8 prose prose-slate max-w-none dark:prose-invert">
              <ReactMarkdown>{(editor?.storage as any).markdown.getMarkdown()}</ReactMarkdown>
            </div>
          )}
        </div>

      <ChapterGallery 
        images={chapter.images || []} 
        onInsert={handleReinsertImage}
        onDelete={handleDeleteImage}
      />

      {researchResult && (
        <div className="mt-8 p-6 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-2xl animate-in slide-in-from-bottom-4 duration-300">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-indigo-900 dark:text-indigo-300">Evidence Summary & Research</h3>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => {
                  editor?.commands.insertContent(`\n\n> ### Research Summary\n> ${researchResult.replace(/\n/g, '\n> ')}`);
                  setResearchResult(null);
                  toast.success("Research added to chapter!");
                }}
                className="bg-indigo-600 text-white text-xs py-1 h-7"
              >
                Insert into Chapter
              </Button>
              <button onClick={() => setResearchResult(null)} className="p-1 hover:bg-indigo-100 rounded">
                <X className="w-4 h-4 text-indigo-400" />
              </button>
            </div>
          </div>
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <ReactMarkdown>{researchResult}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
};

const PreviewMode = ({ project, chapters, onClose, selectedLanguage = 'en' }: { project: Project, chapters: Chapter[], onClose: () => void, selectedLanguage?: string }) => {
  const [activeChapter, setActiveChapter] = useState<number | 'toc'>('toc');
  const [content, setContent] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [showSidebar, setShowSidebar] = useState(true);
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'justify'>(project.formatting?.textAlign || 'left');

  const currentChapter = activeChapter === 'toc' ? null : chapters[activeChapter];
  const currentContentUrl = selectedLanguage === 'en' 
    ? currentChapter?.contentUrl 
    : currentChapter?.translations?.[selectedLanguage]?.contentUrl;

  const currentSummary = selectedLanguage === 'en'
    ? currentChapter?.summary
    : currentChapter?.translations?.[selectedLanguage]?.summary;

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.chapter !== undefined) {
        setActiveChapter(event.state.chapter);
      }
    };
    window.addEventListener('popstate', handlePopState);
    
    // Initial state
    window.history.replaceState({ chapter: 'toc' }, 'Table of Contents');
    
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    if (loading) return; // Don't push state while loading initial content
    const state = { chapter: activeChapter };
    const title = activeChapter === 'toc' ? 'Table of Contents' : `Chapter ${activeChapter + 1}`;
    window.history.pushState(state, title);
  }, [activeChapter]);

  useEffect(() => {
    const fetchContent = async () => {
      if (activeChapter === 'toc') {
        setLoading(false);
        return;
      }
      if (!currentContentUrl) {
        setContent("");
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const response = await fetch(currentContentUrl);
        const text = await response.text();
        setContent(text);
      } catch (err) {
        console.error("Failed to fetch preview content:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchContent();
  }, [currentContentUrl, activeChapter]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-slate-900/95 backdrop-blur-sm flex items-center justify-center p-4 md:p-8"
      role="dialog"
      aria-modal="true"
      aria-labelledby="preview-title"
    >
      <div className="bg-white w-full max-w-5xl h-full rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-white">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-500"
              title="Toggle Navigation"
            >
              <List className="w-5 h-5" />
            </button>
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg">
              <Eye className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h3 id="preview-title" className="font-bold text-slate-900">{project.title}</h3>
              <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Preview Mode ({LANGUAGES.find(l => l.code === selectedLanguage)?.name})</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center bg-slate-50 rounded-lg p-1 border border-slate-200">
              <button 
                onClick={() => setTextAlign('left')}
                className={cn("p-1.5 rounded transition-all", textAlign === 'left' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600")}
                title="Align Left"
              >
                <AlignLeft className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setTextAlign('center')}
                className={cn("p-1.5 rounded transition-all", textAlign === 'center' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600")}
                title="Align Center"
              >
                <AlignCenter className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setTextAlign('justify')}
                className={cn("p-1.5 rounded transition-all", textAlign === 'justify' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600")}
                title="Justify"
              >
                <AlignJustify className="w-4 h-4" />
              </button>
            </div>

            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              aria-label="Close Preview"
            >
              <X className="w-6 h-6 text-slate-400" />
            </button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <AnimatePresence>
            {showSidebar && (
              <motion.div 
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 256, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="border-r border-slate-100 bg-slate-50/50 overflow-y-auto p-4 shrink-0"
              >
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Navigation</h4>
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveChapter('toc')}
                    className={cn(
                      "w-full text-left p-3 rounded-xl text-sm font-medium transition-all flex items-center gap-2",
                      activeChapter === 'toc' 
                        ? "bg-white shadow-sm border border-slate-200 text-indigo-600" 
                        : "text-slate-500 hover:bg-slate-100"
                    )}
                  >
                    <List className="w-4 h-4" />
                    {TOC_TITLES[selectedLanguage] || TOC_TITLES.en}
                  </button>
                  <div className="h-4" />
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Chapters</h4>
                  {chapters.map((ch, idx) => (
                    <button
                      key={ch.id}
                      onClick={() => setActiveChapter(idx)}
                      className={cn(
                        "w-full text-left p-3 rounded-xl text-sm font-medium transition-all",
                        activeChapter === idx 
                          ? "bg-white shadow-sm border border-slate-200 text-indigo-600" 
                          : "text-slate-500 hover:bg-slate-100"
                      )}
                    >
                      {idx + 1}. {selectedLanguage === 'en' ? ch.title : (ch.translations?.[selectedLanguage]?.title || ch.title)}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto bg-slate-50 p-4 md:p-12">
            <div 
              className="max-w-2xl mx-auto bg-white shadow-xl rounded-lg p-8 md:p-16 min-h-full"
              style={{ 
                fontFamily: project.formatting?.fontFamily || 'Inter',
                lineHeight: project.formatting?.lineSpacing || 1.5,
                fontSize: `${project.formatting?.fontSize || 16}px`,
                textAlign: textAlign
              }}
            >
              {loading ? (
                <div className="space-y-4 animate-pulse">
                  <div className="h-8 bg-slate-100 rounded w-3/4" />
                  <div className="h-4 bg-slate-100 rounded w-full" />
                  <div className="h-4 bg-slate-100 rounded w-full" />
                  <div className="h-4 bg-slate-100 rounded w-5/6" />
                </div>
              ) : activeChapter === 'toc' ? (
                <div className="prose prose-slate max-w-none">
                  <h1 className="text-4xl font-bold mb-12 text-center">{TOC_TITLES[selectedLanguage] || TOC_TITLES.en}</h1>
                  <div className="space-y-6">
                    {chapters.map((ch, idx) => (
                      <div key={ch.id} className="flex items-baseline gap-4 group cursor-pointer" onClick={() => setActiveChapter(idx)}>
                        <span className="text-indigo-600 font-bold text-lg">{String(idx + 1).padStart(2, '0')}</span>
                        <div className="flex-1 border-b border-dotted border-slate-200 group-hover:border-indigo-200 transition-colors" />
                        <span className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                          {selectedLanguage === 'en' ? ch.title : (ch.translations?.[selectedLanguage]?.title || ch.title)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : !currentContentUrl && selectedLanguage !== 'en' ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-400 space-y-4">
                  <Languages className="w-12 h-12 opacity-20" />
                  <p>This chapter has not been translated yet.</p>
                </div>
              ) : (
                <div 
                  className="prose prose-slate max-w-none"
                  style={{ 
                    fontFamily: project.formatting?.fontFamily || 'Inter',
                    fontSize: `${project.formatting?.fontSize || 16}px`,
                    lineHeight: project.formatting?.lineSpacing || 1.5,
                    textAlign: textAlign
                  }}
                >
                  <h1 className="text-3xl font-bold mb-4">
                    {selectedLanguage === 'en' ? currentChapter?.title : (currentChapter?.translations?.[selectedLanguage]?.title || currentChapter?.title)}
                  </h1>
                  
                  {currentSummary && (
                    <div className="bg-slate-50 p-6 rounded-xl border border-slate-100 mb-8">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Summary</h4>
                      <p className="text-sm text-slate-600 italic leading-relaxed">"{currentSummary}"</p>
                    </div>
                  )}

                  <ReactMarkdown>{content}</ReactMarkdown>

                  {currentChapter?.factCheck && (
                    <div className="mt-12 pt-8 border-t border-slate-100">
                      <div className="flex items-center gap-2 mb-4">
                        <ShieldCheck className="w-5 h-5 text-indigo-600" />
                        <h4 className="text-sm font-bold text-slate-900">Fact-Check Verification</h4>
                      </div>
                      <div className="space-y-3">
                        {currentChapter.factCheck.claims.map((claim, cIdx) => (
                          <div 
                            key={cIdx} 
                            className={cn(
                              "p-3 rounded-lg border text-xs",
                              claim.status === 'accurate' ? "bg-emerald-50 border-emerald-100 text-emerald-800" :
                              claim.status === 'inaccurate' ? "bg-red-50 border-red-100 text-red-800" :
                              "bg-amber-50 border-amber-100 text-amber-800"
                            )}
                          >
                            <div className="font-bold mb-1">Claim: "{claim.claim}"</div>
                            <div className="opacity-80">{claim.evidence}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mt-16 pt-8 border-t border-slate-100 flex justify-between items-center">
                    <button 
                      onClick={() => {
                        if (typeof activeChapter === 'number' && activeChapter === 0) setActiveChapter('toc');
                        else if (typeof activeChapter === 'number') setActiveChapter(activeChapter - 1);
                      }}
                      className="text-sm font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-2"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </button>
                    {((activeChapter as any) === 'toc' || (typeof activeChapter === 'number' && activeChapter < chapters.length - 1)) && (
                      <button 
                        onClick={() => {
                          if ((activeChapter as any) === 'toc') setActiveChapter(0);
                          else if (typeof activeChapter === 'number') setActiveChapter(activeChapter + 1);
                        }}
                        className="text-sm font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-2"
                      >
                        Next
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-white flex justify-between items-center">
          <div className="flex gap-2">
             <button 
               disabled={activeChapter === 0 || activeChapter === 'toc'}
               onClick={() => setActiveChapter(prev => typeof prev === 'number' ? prev - 1 : 0)}
               className="p-2 rounded-lg border border-slate-200 disabled:opacity-30 hover:bg-slate-50 transition-colors"
             >
               <ArrowLeft className="w-5 h-5" />
             </button>
             <button 
               disabled={activeChapter === chapters.length - 1}
               onClick={() => setActiveChapter(prev => typeof prev === 'number' ? prev + 1 : 0)}
               className="p-2 rounded-lg border border-slate-200 disabled:opacity-30 hover:bg-slate-50 transition-colors"
             >
               <ChevronRight className="w-5 h-5" />
             </button>
          </div>
          <p className="text-xs font-bold text-slate-400">
            {activeChapter === 'toc' ? 'Table of Contents' : `Chapter ${(activeChapter as number) + 1} of ${chapters.length}`}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

const FullScreenProcessOverlay = ({ 
  isVisible, 
  title, 
  message, 
  progress, 
  steps 
}: { 
  isVisible: boolean; 
  title: string; 
  message: string; 
  progress?: number;
  steps?: { label: string; status: 'pending' | 'active' | 'complete' }[];
}) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] bg-white/90 dark:bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
          role="status"
          aria-live="polite"
        >
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="max-w-xl w-full bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-8 space-y-8"
          >
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/30 rounded-3xl flex items-center justify-center mx-auto mb-6 relative">
                <Loader2 className="w-10 h-10 text-indigo-600 dark:text-indigo-400 animate-spin" aria-hidden="true" />
                <Sparkles className="w-5 h-5 text-amber-400 absolute -top-2 -right-2 animate-pulse" aria-hidden="true" />
              </div>
              <h2 className="text-3xl font-bold tracking-tight dark:text-white">{title}</h2>
              <p className="text-slate-600 dark:text-slate-400 text-lg">{message}</p>
            </div>

            {progress !== undefined && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <span>Progress</span>
                  <span className="text-indigo-600 dark:text-indigo-400">{Math.round(progress)}%</span>
                </div>
                <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden" role="progressbar" aria-valuenow={Math.round(progress)} aria-valuemin={0} aria-valuemax={100}>
                  <motion.div 
                    className="h-full bg-indigo-600 dark:bg-indigo-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ type: "spring", stiffness: 50 }}
                  />
                </div>
              </div>
            )}

            {steps && steps.length > 0 && (
              <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
                {steps.map((step, idx) => (
                  <div key={idx} className="flex items-center gap-4">
                    <div className={cn(
                      "w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-colors",
                      step.status === 'complete' ? "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400" :
                      step.status === 'active' ? "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400" :
                      "bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-500"
                    )}>
                      {step.status === 'complete' ? <CheckCircle2 className="w-3.5 h-3.5" /> : 
                       step.status === 'active' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 
                       <span className="text-[10px] font-bold">{idx + 1}</span>}
                    </div>
                    <span className={cn(
                      "text-sm font-medium transition-colors",
                      step.status === 'complete' ? "text-slate-900 dark:text-white" :
                      step.status === 'active' ? "text-indigo-600 dark:text-indigo-400 font-bold" :
                      "text-slate-500 dark:text-slate-500"
                    )}>
                      {step.label}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const ProjectProgress = ({ project }: { project: Project }) => {
  const steps = [
    { id: 'outline', label: 'Outline', completed: project.outline && project.outline.length > 0 },
    { id: 'content', label: 'Content', completed: project.status === 'ready' || project.status === 'published' },
    { id: 'cover', label: 'Cover', completed: !!project.coverUrl },
    { id: 'translation', label: 'Translation', completed: !!project.isTranslated },
    { id: 'publishing', label: 'Publishing', completed: project.status === 'published' }
  ];

  const completedCount = steps.filter(s => s.completed).length;
  const progressPercent = (completedCount / steps.length) * 100;

  return (
    <div className="space-y-2" role="group" aria-label="Project Progress">
      <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-slate-500">
        <span>Progress</span>
        <span className="text-indigo-600 dark:text-indigo-400">{Math.round(progressPercent)}%</span>
      </div>
      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex gap-0.5" role="progressbar" aria-valuenow={Math.round(progressPercent)} aria-valuemin={0} aria-valuemax={100}>
        {steps.map((step, idx) => (
          <div 
            key={step.id}
            className={cn(
              "h-full flex-1 transition-all duration-500",
              step.completed ? "bg-indigo-500" : "bg-slate-200 dark:bg-slate-700"
            )}
            title={step.label}
            aria-label={`${step.label}: ${step.completed ? 'Completed' : 'Pending'}`}
          />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-1">
        {steps.map(step => (
          <div key={step.id} className="flex items-center gap-1">
            <div className={cn(
              "w-1.5 h-1.5 rounded-full",
              step.completed ? "bg-green-500" : "bg-slate-300 dark:bg-slate-600"
            )} />
            <span className={cn(
              "text-[9px] font-medium",
              step.completed ? "text-slate-600 dark:text-slate-300" : "text-slate-400"
            )}>
              {step.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [currentChapters, setCurrentChapters] = useState<Chapter[]>([]);
  const [step, setStep] = useState<'list' | 'template' | 'niche' | 'upload' | 'outline' | 'generate' | 'cover' | 'publish' | 'done'>('list');
  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState("");
  const [generationPercent, setGenerationPercent] = useState(0);
  const [fontFamily, setFontFamily] = useState("Inter");
  const [lineSpacing, setLineSpacing] = useState(1.5);
  const [fontSize, setFontSize] = useState(16);
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'justify'>('left');
  const [coverKeywords, setCoverKeywords] = useState("");
  const [coverStyles, setCoverStyles] = useState<string[]>(["modern, minimalist"]);
  const [writingStyle, setWritingStyle] = useState("conversational");
  const [tone, setTone] = useState("Professional");
  const [audience, setAudience] = useState("Beginner");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [dbError, setDbError] = useState(false);
  const [isAutoGeneratingCover, setIsAutoGeneratingCover] = useState(false);
  const [editableOutline, setEditableOutline] = useState<{ title: string, description: string, writingStyle?: string }[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [chapterStatuses, setChapterStatuses] = useState<Record<number, 'pending' | 'generating' | 'saving' | 'complete'>>({});
  const [chapterWordCounts, setChapterWordCounts] = useState<Record<string, number>>({});
  const [userLogoUrl, setUserLogoUrl] = useState<string | null>(localStorage.getItem('ebookforge_logo'));
  const [showSettings, setShowSettings] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportFormat, setExportFormat] = useState<'zip' | 'epub' | 'pdf'>('epub');
  const [exportPageSize, setExportPageSize] = useState<'a4' | 'letter'>('a4');
  const [exportIncludeCover, setExportIncludeCover] = useState(true);
  const [showProjectDetails, setShowProjectDetails] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en');
  const [showAllNiches, setShowAllNiches] = useState(false);
  const [isAnalyzingTrends, setIsAnalyzingTrends] = useState(false);
  const [discoveredNiches, setDiscoveredNiches] = useState<NicheOption[]>([]);
  const [isTranslating, setIsTranslating] = useState(false);
  const [showTranslationModal, setShowTranslationModal] = useState(false);
  const [appTheme, setAppTheme] = useState<'light' | 'dark' | 'high-contrast'>((localStorage.getItem('ebookforge_theme') as 'light' | 'dark' | 'high-contrast') || 'light');
  const [appFont, setAppFont] = useState<string>(localStorage.getItem('ebookforge_ui_font') || 'Inter');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [customTemplates, setCustomTemplates] = useState<ProjectTemplate[]>(() => {
    const stored = localStorage.getItem('custom_ebook_templates');
    return stored ? JSON.parse(stored) : [];
  });
  const [showCustomTemplateModal, setShowCustomTemplateModal] = useState(false);
  const [newTemplateData, setNewTemplateData] = useState<Partial<ProjectTemplate>>({
    name: '',
    description: '',
    defaultWritingStyle: '',
    defaultTone: 'Professional',
    defaultAudience: 'General',
  });

  const [processState, setProcessState] = useState<{
    isVisible: boolean;
    title: string;
    message: string;
    progress?: number;
    steps?: { label: string; status: 'pending' | 'active' | 'complete' }[];
  } | null>(null);

  // EbookFactory SaaS Unified Architecture State
  const [currentView, setCurrentView] = useState<'storefront' | 'creator' | 'niche' | 'library'>('storefront');
  const [userRole, setUserRole] = useState<'admin' | 'user'>('user');
  const isAdmin = userRole === 'admin';
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orders, setOrders] = useState<CompletedOrder[]>([]);

  const handleAddToCart = (product: StorefrontProduct) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
    toast.success(`Added "${product.title}" to cart!`);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleCompleteOrder = (order: CompletedOrder) => {
    setOrders(prev => [order, ...prev]);
  };

  const handleTurnNicheIntoProject = (nicheData: { title: string; subtitle: string; niche: string; audience: string; targetPrice: number }) => {
    setCurrentView('creator');
    setStep('niche');
    toast.success(`Launching Ebook Studio for "${nicheData.title}"!`);
  };

  const [marketplaceUrls, setMarketplaceUrls] = useState({
    amazon: '',
    apple: '',
    google: '',
    other: ''
  });
  const [showCollaboratorsModal, setShowCollaboratorsModal] = useState(false);

  useEffect(() => {
    localStorage.setItem('custom_ebook_templates', JSON.stringify(customTemplates));
  }, [customTemplates]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowSettings(false);
        setShowProjectDetails(false);
        setShowTranslationModal(false);
        setShowPreview(false);
        setShowCollaboratorsModal(false);
        setProjectToDelete(null);
        setShowCustomTemplateModal(false);
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, []);

  const inviteCollaborator = async (email: string, role: 'editor' | 'viewer') => {
    if (!currentProject?.id) return;
    const collaborator = {
      email,
      role,
      invitedAt: new Date().toISOString()
    };
    await updateDoc(doc(db, 'projects', currentProject.id), {
      collaborators: arrayUnion(collaborator),
      collaboratorEmails: arrayUnion(email),
      updatedAt: serverTimestamp()
    });
  };

  const removeCollaborator = async (email: string) => {
    if (!currentProject?.id) return;
    const collaborator = currentProject.collaborators?.find(c => c.email === email);
    if (!collaborator) return;
    await updateDoc(doc(db, 'projects', currentProject.id), {
      collaborators: arrayRemove(collaborator),
      collaboratorEmails: arrayRemove(email),
      updatedAt: serverTimestamp()
    });
  };

  // Role Sync and Authorization Effect (Derived strictly from token custom claims or users/{uid}.role in Firestore)
  useEffect(() => {
    if (!user) {
      setUserRole('user');
      return;
    }

    user.getIdTokenResult(true).then((tokenResult) => {
      if (tokenResult.claims.admin === true) {
        setUserRole('admin');
      }
    }).catch((err) => {
      console.warn("Could not check custom claims:", err);
    });

    const userDocRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.role === 'admin') {
          setUserRole('admin');
        } else {
          setUserRole('user');
        }

        if (data.settings) {
          if (data.settings.theme) setAppTheme(data.settings.theme);
          if (data.settings.uiFont) setAppFont(data.settings.uiFont);
          if (data.settings.customLogoUrl) setUserLogoUrl(data.settings.customLogoUrl);
        }
      }
    }, (error) => {
      console.error("Error syncing user profile/role:", error);
    });
    return unsubscribe;
  }, [user]);

  // Non-Admin Navigation Guard
  useEffect(() => {
    if (!isAdmin && (currentView === 'creator' || currentView === 'niche')) {
      setCurrentView('storefront');
    }
  }, [isAdmin]);

  const updateUserSettings = async (newSettings: any) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.uid), {
        email: user.email || 'user@example.com',
        displayName: user.displayName || 'Creator',
        settings: newSettings,
        updatedAt: serverTimestamp()
      }, { merge: true });
      toast.success("Settings saved!");
    } catch (err) {
      console.error("Failed to update settings:", err);
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const handleDiscoverTrends = async () => {
    setIsAnalyzingTrends(true);
    toast.info("Scraping current global trends and market demand...");
    try {
      const results = await analyzeTrendingNiches();
      if (results && results.length > 0) {
        setDiscoveredNiches(results);
        toast.success(`Found ${results.length} high-potential trending niches!`);
      } else {
        toast.error("Could not identify new trends at this moment.");
      }
    } catch (err) {
      handleAIError(err, "Trend analysis");
    } finally {
      setIsAnalyzingTrends(false);
    }
  };

  const totalWordCount = Object.values(chapterWordCounts).reduce((sum, count) => sum + count, 0);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('dark', 'high-contrast');
    if (appTheme === 'dark') {
      root.classList.add('dark');
    } else if (appTheme === 'high-contrast') {
      root.classList.add('dark', 'high-contrast');
    }
    localStorage.setItem('ebookforge_theme', appTheme);
  }, [appTheme]);

  useEffect(() => {
    document.documentElement.style.setProperty('--ui-font', `'${appFont}', sans-serif`);
    localStorage.setItem('ebookforge_ui_font', appFont);
  }, [appFont]);

  const exportOutline = () => {
    if (!currentProject) return;
    const outlineData = {
      projectTitle: currentProject.title,
      niche: currentProject.niche,
      tone: currentProject.tone,
      writingStyle: currentProject.writingStyle,
      audience: currentProject.audience,
      chapters: editableOutline
    };
    
    const blob = new Blob([JSON.stringify(outlineData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentProject.title.replace(/\s+/g, '_')}_outline.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Outline exported as JSON!");
  };

  const applyChapterTemplate = (idx: number, templateId: string) => {
    const template = CHAPTER_TEMPLATES.find(t => t.id === templateId);
    if (!template) return;
    
    const newOutline = [...editableOutline];
    newOutline[idx] = {
      ...newOutline[idx],
      title: template.title,
      description: template.description
    };
    setEditableOutline(newOutline);
    toast.success(`Applied ${template.title} template`);
  };

  const formatError = (err: any, context: string) => {
    const { title, message } = classifyAIError(err, context);
    return `${title}: ${message}`;
  };
  
  // Refs for auto-save to avoid interval resets
  const saveRef = useRef({ currentProject, editableOutline, fontFamily, lineSpacing, fontSize, textAlign, coverStyles, coverKeywords, step });
  useEffect(() => {
    saveRef.current = { currentProject, editableOutline, fontFamily, lineSpacing, fontSize, textAlign, coverStyles, coverKeywords, step };
  }, [currentProject, editableOutline, fontFamily, lineSpacing, fontSize, textAlign, coverStyles, coverKeywords, step]);

  // Periodic Auto-save effect
  useEffect(() => {
    if (!currentProject?.id || step === 'list' || step === 'done') return;

    const interval = setInterval(async () => {
      const { currentProject: cp, editableOutline: eo, fontFamily: ff, lineSpacing: ls, fontSize: fs, textAlign: ta, coverStyles: cs, coverKeywords: ck, step: s } = saveRef.current;
      if (!cp?.id || s === 'list' || s === 'done') return;

      setIsSaving(true);
      try {
        await updateDoc(doc(db, 'projects', cp.id), {
          outline: eo,
          formatting: {
            fontFamily: ff,
            lineSpacing: ls,
            fontSize: fs,
            textAlign: ta
          },
          coverStyles: cs,
          coverKeywords: ck,
          updatedAt: serverTimestamp()
        });
        setLastSaved(new Date());
      } catch (err) {
        console.error("Auto-save failed:", err);
      } finally {
        setIsSaving(false);
      }
    }, 30000); // 30 seconds periodic save

    return () => clearInterval(interval);
  }, [currentProject?.id, step]);

  // Auto-generate cover art when style or keywords change
  useEffect(() => {
    if (step !== 'cover' || !currentProject?.id || isGenerating) return;
    
    const timer = setTimeout(() => {
      generateCover();
    }, 2500); // 2.5s debounce for image generation

    return () => clearTimeout(timer);
  }, [coverKeywords, coverStyles, step]);

  useEffect(() => {
    if (currentProject?.marketplaceLinks) {
      setMarketplaceUrls({
        amazon: currentProject.marketplaceLinks.amazon || '',
        apple: currentProject.marketplaceLinks.apple || '',
        google: currentProject.marketplaceLinks.google || '',
        other: currentProject.marketplaceLinks.other || ''
      });
    } else {
      setMarketplaceUrls({ amazon: '', apple: '', google: '', other: '' });
    }
  }, [currentProject?.id]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const syncOfflineQueue = async () => {
    if (!navigator.onLine) return;
    try {
      const pending = await getPendingOfflineActions();
      if (!pending || pending.length === 0) return;

      console.log(`[Offline Sync] Synchronizing ${pending.length} unsynced change(s)...`);
      toast.info(`Syncing ${pending.length} offline change(s)...`);

      for (const action of pending) {
        try {
          if (action.type === 'save-draft') {
            await updateDoc(doc(db, 'projects', action.projectId), {
              ...action.data,
              updatedAt: serverTimestamp()
            });
          } else if (action.type === 'toggle-review') {
            await updateDoc(doc(db, 'projects', action.projectId, 'chapters', action.chapterId!), {
              isReviewed: action.data.isReviewed,
              updatedAt: serverTimestamp()
            });
          } else if (action.type === 'save-chapter') {
            const { content: markdownContent, index, language } = action.data;
            const fileName = language === 'en'
              ? `chapter_${index}.md`
              : `chapter_${index}_${language}.md`;

            const storageRef = ref(storage, `projects/${action.projectId}/chapters/${fileName}`);
            await uploadString(storageRef, markdownContent);
            const contentUrl = await getDownloadURL(storageRef);

            if (language === 'en') {
              await updateDoc(doc(db, 'projects', action.projectId, 'chapters', action.chapterId!), {
                contentUrl,
                updatedAt: serverTimestamp()
              });
            } else {
              const chapterDoc = await getDoc(doc(db, 'projects', action.projectId, 'chapters', action.chapterId!));
              const chapterData = chapterDoc.data();
              const translations = { ...(chapterData?.translations || {}) };
              translations[language] = {
                ...translations[language],
                contentUrl
              };
              await updateDoc(doc(db, 'projects', action.projectId, 'chapters', action.chapterId!), {
                translations,
                updatedAt: serverTimestamp()
              });
            }
          }

          // Successfully synced, remove from queue
          await removeOfflineAction(action.id!);
          
          if (action.chapterId) {
            const cached = await getCachedChapter(action.chapterId);
            if (cached) {
              await cacheChapter(action.projectId, cached, undefined, false);
            }
          }
        } catch (itemErr) {
          console.error("IndexedDB sync list item processing error:", action, itemErr);
          throw itemErr; // halt and retry on subsequent runs to preserve order
        }
      }

      toast.success("Offline changes synced with cloud!");
    } catch (syncErr) {
      console.warn("Offline sync queue execution paused:", syncErr);
    }
  };

  useEffect(() => {
    const handleOnline = () => {
      console.log("[Network Status] Online connection restored. Resolving unsynced actions...");
      syncOfflineQueue();
    };

    window.addEventListener('online', handleOnline);

    // Run periodic sync resolver
    const timer = setInterval(() => {
      syncOfflineQueue();
    }, 20000);

    return () => {
      window.removeEventListener('online', handleOnline);
      clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    const checkConnection = async () => {
      const isConnected = await testFirestoreConnection();
      if (!isConnected) setDbError(true);
    };
    checkConnection();
  }, []);

  // Initial load of cached projects for instant/offline display
  useEffect(() => {
    if (!user) return;
    getCachedProjects()
      .then((cachedDocs) => {
        if (cachedDocs && cachedDocs.length > 0) {
          console.log("[Offline Cache] Loaded projects count:", cachedDocs.length);
          setProjects(cachedDocs.sort((a, b) => {
            const aTime = a.createdAt?.seconds || (typeof a.createdAt === 'object' && a.createdAt?.getTime ? a.createdAt.getTime() / 1000 : 0) || 0;
            const bTime = b.createdAt?.seconds || (typeof b.createdAt === 'object' && b.createdAt?.getTime ? b.createdAt.getTime() / 1000 : 0) || 0;
            return bTime - aTime;
          }));
        }
      })
      .catch((err) => console.warn("Failed to load projects from IndexedDB:", err));
  }, [user]);

  useEffect(() => {
    if (!user) {
      setProjects([]);
      return;
    }

    const q = query(
      collection(db, 'projects'), 
      or(
        where('userId', '==', user.uid), 
        where('collaboratorEmails', 'array-contains', user.email)
      )
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const pList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Project));
      const sortedProjects = pList.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
      setProjects(sortedProjects);
      
      // Cache these projects in IDB for offline accessibility
      sortedProjects.forEach(proj => {
        cacheProject(proj).catch((err) => console.warn("Could not cache project:", err));
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
    });
    return unsubscribe;
  }, [user]);

  useEffect(() => {
    if (currentProject?.outline) {
      setEditableOutline(currentProject.outline);
    } else {
      setEditableOutline([]);
    }
    
    if (currentProject) {
      setFontFamily(currentProject.formatting?.fontFamily || "Inter");
      setLineSpacing(currentProject.formatting?.lineSpacing || 1.5);
      setFontSize(currentProject.formatting?.fontSize || 16);
      setTextAlign(currentProject.formatting?.textAlign || 'left');
      setCoverKeywords(currentProject.coverKeywords || "");
      setCoverStyles(currentProject.coverStyles || ["modern, minimalist"]);
    } else {
      setFontFamily("Inter");
      setLineSpacing(1.5);
      setFontSize(16);
      setTextAlign('left');
      setCoverKeywords("");
      setCoverStyles(["modern, minimalist"]);
    }
  }, [currentProject?.id]);

  // Fetch chapters when currentProject changes
  useEffect(() => {
    if (!currentProject?.id) {
      setCurrentChapters([]);
      return;
    }

    // Try loading cached chapters first for instant display and offline mode
    getCachedChaptersForProject(currentProject.id)
      .then((cachedChapters) => {
        if (cachedChapters && cachedChapters.length > 0 && currentChapters.length === 0) {
          console.log("[Offline Cache] Loaded chapters count:", cachedChapters.length);
          setCurrentChapters(cachedChapters);
        }
      })
      .catch((err) => console.warn("Failed to get chapters from IDB cache:", err));

    const q = query(collection(db, 'projects', currentProject.id, 'chapters'), orderBy('index', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const cList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter));
      setCurrentChapters(cList);
      
      // Cache these chapters locally for offline access
      cList.forEach((ch) => {
        cacheChapter(currentProject.id!, ch).catch((err) => console.warn("Failed to cache chapter in IndexedDB:", err));
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${currentProject.id}/chapters`);
    });
    return unsubscribe;
  }, [currentProject?.id]);

  const login = async () => {
    try {
      const result = await signInWithPopup(auth, new GoogleAuthProvider());
      const u = result.user;
      
      try {
        const userDocRef = doc(db, 'users', u.uid);
        const userDocSnap = await getDoc(userDocRef);
        if (!userDocSnap.exists()) {
          await setDoc(userDocRef, {
            email: u.email,
            displayName: u.displayName,
            role: 'user',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            settings: {
              theme: 'light',
              uiFont: 'Inter'
            }
          });
        }
      } catch (docErr) {
        console.warn("Could not sync user profile to Firestore (client may be offline/initializing):", docErr);
      }
    } catch (err) {
      console.error("Login error:", err);
      toast.error("Login failed. Please try again.");
    }
  };
  const logout = () => signOut(auth);

  const createNewProject = () => {
    setCurrentProject(null);
    setSelectedTemplate(null);
    setStep('template');
  };

  const selectTemplate = (template: ProjectTemplate) => {
    setSelectedTemplate(template);
    setShowAllNiches(false);
    setFontFamily(template.defaultFormatting.fontFamily);
    setLineSpacing(template.defaultFormatting.lineSpacing);
    setFontSize(template.defaultFormatting.fontSize);
    setTextAlign(template.defaultFormatting.textAlign);
    setWritingStyle(template.defaultWritingStyle);
    setTone(template.defaultTone);
    setAudience(template.defaultAudience);
    setStep('niche');
  };

  const selectNiche = async (niche: NicheOption) => {
    if (!user) return;
    try {
      const newProject: Record<string, any> = {
        userId: user.uid,
        niche: niche.title || "General",
        title: `Untitled Ebook - ${niche.title || "General"}`,
        status: 'draft',
        writingStyle: writingStyle || 'Professional & Educational',
        tone: tone || 'Informative',
        audience: audience || 'General Readers',
        autoFactCheck: true,
        formatting: {
          fontFamily: fontFamily || 'Inter',
          lineSpacing: lineSpacing || 1.5,
          fontSize: fontSize || 16,
          textAlign: textAlign || 'left'
        },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      if (selectedTemplate?.id) {
        newProject.templateId = selectedTemplate.id;
      }

      const docRef = await addDoc(collection(db, 'projects'), newProject);
      setCurrentProject({ id: docRef.id, ...newProject } as Project);
      setStep('upload');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'projects');
    }
  };

  const updateMarketplaceLink = async (platform: string, url: string) => {
    if (!currentProject?.id) return;
    try {
      const updatedLinks = {
        ...(currentProject.marketplaceLinks || {}),
        [platform]: url
      };
      await updateDoc(doc(db, 'projects', currentProject.id), {
        marketplaceLinks: updatedLinks,
        updatedAt: serverTimestamp()
      });
      setCurrentProject(prev => prev ? { ...prev, marketplaceLinks: updatedLinks } : null);
      toast.success(`${platform.charAt(0).toUpperCase() + platform.slice(1)} link updated!`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `projects/${currentProject.id}`);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!currentProject?.id) return;
    const file = e.target.files?.[0];
    if (!file) return;

    // Simulate upload and basic text extraction
    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      
      // Upload to Storage
      const storageRef = ref(storage, `projects/${currentProject.id}/chapters/imported.md`);
      await uploadString(storageRef, text);
      const contentUrl = await getDownloadURL(storageRef);

      // Split text into a single chapter for now if it's an upload
      await addDoc(collection(db, 'projects', currentProject.id!, 'chapters'), {
        index: 0,
        title: "Imported Content",
        contentUrl
      });

      await updateDoc(doc(db, 'projects', currentProject.id!), {
        updatedAt: serverTimestamp()
      });
      setStep('generate');
    };
    reader.readAsText(file);
  };

  const handleSaveDraft = async () => {
    if (!currentProject?.id) return;
    setIsSaving(true);
    
    const safeOutline = editableOutline.slice(0, 19).map(c => ({
      ...c,
      title: String(c.title || "Untitled").substring(0, 199),
      description: String(c.description || "Description").substring(0, 999)
    }));

    const updatePayload = {
      outline: safeOutline,
      formatting: {
        fontFamily,
        lineSpacing,
        fontSize,
        textAlign
      },
      coverStyles,
      coverKeywords
    };

    // Store in IndexedDB optimistically
    try {
      await cacheProject({
        ...currentProject,
        ...updatePayload
      });
    } catch (cacheErr) {
      console.warn("Could not cache draft locally:", cacheErr);
    }

    try {
      if (!navigator.onLine) {
        throw new Error("Network is offline");
      }
      await updateDoc(doc(db, 'projects', currentProject.id), {
        ...updatePayload,
        updatedAt: serverTimestamp()
      });
      setLastSaved(new Date());
      toast.success("Draft saved successfully!");
    } catch (err) {
      if (!navigator.onLine || (err instanceof Error && err.message.includes("offline"))) {
        await queueOfflineAction({
          type: 'save-draft',
          projectId: currentProject.id,
          data: updatePayload
        });
        setLastSaved(new Date());
        toast.info("Draft saved offline. Will sync when connection is restored!");
      } else {
        console.error("Manual save failed:", err);
        toast.error("Failed to save draft.");
      }
    } finally {
      setIsSaving(false);
    }
  };

  const toggleChapterReview = async (chapterId: string, isReviewed: boolean) => {
    if (!currentProject?.id) return;

    // Optimistically update IndexedDB cache
    try {
      const cached = await getCachedChapter(chapterId);
      if (cached) {
        cached.isReviewed = !isReviewed;
        await cacheChapter(currentProject.id, cached, undefined, true);
      }
    } catch (e) {
      console.warn("Could not cache chapter review status locally:", e);
    }

    try {
      if (!navigator.onLine) {
        throw new Error("Network is offline");
      }
      await updateDoc(doc(db, 'projects', currentProject.id, 'chapters', chapterId), {
        isReviewed: !isReviewed,
        updatedAt: serverTimestamp()
      });
      toast.success(isReviewed ? "Marked as unreviewed" : "Marked as reviewed");
    } catch (err) {
      if (!navigator.onLine || (err instanceof Error && err.message.includes("offline"))) {
        await queueOfflineAction({
          type: 'toggle-review',
          projectId: currentProject.id,
          chapterId,
          data: { isReviewed: !isReviewed }
        });
        toast.info("Status changes saved offline. Will sync with cloud once reconnected!");
      } else {
        console.error("Failed to update chapter review status:", err);
        toast.error("Failed to update review status.");
      }
    }
  };

  useEffect(() => {
    (window as any).toggleChapterReview = toggleChapterReview;
  }, [toggleChapterReview]);

  const startGeneration = async () => {
    if (!currentProject?.id) {
      toast.error("Project context lost. Please select the niche again.");
      console.error("startGeneration: No currentProject ID");
      return;
    }
    
    setIsGenerating(true);
    setGenerationProgress("Forging outline...");
    
    setProcessState({
      isVisible: true,
      title: "Forging Outline",
      message: "Analyzing niche and target audience...",
      progress: 0,
      steps: [
        { label: "Analyzing Niche", status: "active" },
        { label: "Structuring Chapters", status: "pending" },
        { label: "Finalizing Outline", status: "pending" }
      ]
    });

    try {
      if (!currentProject.niche) {
        throw new Error("Niche information is missing from the project.");
      }

      // Clear existing chapters first
      const chaptersSnapshot = await getDocs(collection(db, 'projects', currentProject.id, 'chapters'));
      const deletePromises = chaptersSnapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);

      setProcessState(prev => prev ? { ...prev, progress: 33, message: "Structuring chapter flow...", steps: [
        { label: "Analyzing Niche", status: "complete" },
        { label: "Structuring Chapters", status: "active" },
        { label: "Finalizing Outline", status: "pending" }
      ]} : null);

      const outline = await generateEbookOutline(currentProject.niche, writingStyle);
      
      if (!outline || !outline.chapters || outline.chapters.length === 0) {
        throw new Error("AI failed to generate a valid ebook outline. Please try again.");
      }

      setProcessState(prev => prev ? { ...prev, progress: 80, message: "Saving outline to project...", steps: [
        { label: "Analyzing Niche", status: "complete" },
        { label: "Structuring Chapters", status: "complete" },
        { label: "Finalizing Outline", status: "active" }
      ]} : null);

      // Enforce strict constraints to comply with Firestore security rules
      const safeTitle = String(outline.title || currentProject.title).substring(0, 99);
      const safeChapters = outline.chapters.slice(0, 19).map((c: any) => ({
        title: String(c.title || c.chapterTitle || "Untitled Chapter").substring(0, 199),
        description: String(c.description || c.desc || c.summary || "Chapter description.").substring(0, 999)
      }));

      await updateDoc(doc(db, 'projects', currentProject.id!), {
        title: safeTitle,
        outline: safeChapters,
        updatedAt: serverTimestamp()
      });
      
      setProcessState(prev => prev ? { ...prev, progress: 100, message: "Outline complete!", steps: [
        { label: "Analyzing Niche", status: "complete" },
        { label: "Structuring Chapters", status: "complete" },
        { label: "Finalizing Outline", status: "complete" }
      ]} : null);

      // Brief pause to show completion
      await new Promise(r => setTimeout(r, 800));

      setEditableOutline(safeChapters);
      setCurrentProject(prev => prev ? { ...prev, title: safeTitle, outline: safeChapters } : null);
      setStep('outline');
      toast.success("Ebook outline generated successfully!");
    } catch (err) {
      handleAIError(err, "Outline generation");
      setError(formatError(err, "Outline generation"));
    } finally {
      setIsGenerating(false);
      setGenerationProgress("");
      setProcessState(null);
    }
  };

  const generateFullContent = async () => {
    if (!currentProject?.id || !editableOutline.length) return;
    setIsGenerating(true);
    setGenerationPercent(0);
    setStep('generate');
    setChapterStatuses({});
    
    setProcessState({
      isVisible: true,
      title: "Synthesizing Ebook",
      message: "Orchestrating AI to draft your content...",
      progress: 0,
      steps: editableOutline.map((ch, i) => ({ label: `Chapter ${i + 1}: ${ch.title}`, status: 'pending' }))
    });
    
    try {
      // Clear existing chapters first
      const chaptersSnapshot = await getDocs(collection(db, 'projects', currentProject.id, 'chapters'));
      const deletePromises = chaptersSnapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);

      const initialStatuses: Record<number, 'pending' | 'generating' | 'saving' | 'complete'> = {};
      editableOutline.forEach((_, i) => initialStatuses[i] = 'pending');
      setChapterStatuses(initialStatuses);

      for (let i = 0; i < editableOutline.length; i++) {
        const ch = editableOutline[i];
        
        setProcessState(prev => prev ? {
          ...prev,
          progress: Math.round((i / editableOutline.length) * 100),
          message: `Generating Chapter ${i + 1}: ${ch.title}...`,
          steps: prev.steps?.map((s, idx) => ({
            ...s,
            status: idx === i ? 'active' : idx < i ? 'complete' : 'pending'
          }))
        } : null);

        setChapterStatuses(prev => ({ ...prev, [i]: 'generating' }));
        setGenerationProgress(`Generating Chapter ${i + 1}: ${ch.title}...`);
        setGenerationPercent(Math.round((i / editableOutline.length) * 100));
        
        const chContent = await generateChapterContent(
          currentProject.title, 
          ch.title, 
          ch.description, 
          currentProject.tone || tone, 
          currentProject.audience || audience, 
          ch.writingStyle || writingStyle
        );
        
        if (!chContent) throw new Error(`No content generated for chapter ${i + 1}`);

        // Generate summary
        setGenerationProgress(`Summarizing Chapter ${i + 1}...`);
        const chSummaryRaw = await generateChapterSummary(ch.title, chContent);
        const chSummary = String(chSummaryRaw || "").substring(0, 999);

        setChapterStatuses(prev => ({ ...prev, [i]: 'saving' }));
        // Upload to Storage
        const storageRef = ref(storage, `projects/${currentProject.id}/chapters/chapter_${i}.md`);
        await uploadString(storageRef, chContent);
        const contentUrl = await getDownloadURL(storageRef);

        // Save chapter to subcollection
        const chapterData: any = {
          index: i,
          title: String(ch.title || "Untitled Chapter").substring(0, 199),
          contentUrl,
          summary: chSummary,
          writingStyle: String(ch.writingStyle || writingStyle || "").substring(0, 499),
          isReviewed: false,
          createdAt: serverTimestamp()
        };

        // Auto Fact-Check if enabled
        if (currentProject.autoFactCheck) {
          setGenerationProgress(`Fact-checking Chapter ${i + 1}...`);
          try {
            const factResults = await factCheckContent(chContent, currentProject.niche, currentProject.tone);
            chapterData.factCheck = {
              lastCheckedAt: serverTimestamp(),
              claims: factResults.claims
            };
          } catch (fErr) {
            console.error("Auto fact-check failed:", fErr);
          }
        }

        await addDoc(collection(db, 'projects', currentProject.id!, 'chapters'), chapterData);
        setChapterStatuses(prev => ({ ...prev, [i]: 'complete' }));
      }

      setProcessState(prev => prev ? {
        ...prev,
        progress: 100,
        message: "Ebook synthesis complete!",
        steps: prev.steps?.map(s => ({ ...s, status: 'complete' }))
      } : null);

      setGenerationPercent(100);
      await updateDoc(doc(db, 'projects', currentProject.id!), {
        status: 'ready',
        updatedAt: serverTimestamp()
      });

      // Brief wait to show completion
      await new Promise(r => setTimeout(r, 1000));
      setStep('cover');
    } catch (err) {
      handleAIError(err, "Content generation");
      setError(formatError(err, "Content generation"));
    } finally {
      setIsGenerating(false);
      setGenerationProgress("");
      setProcessState(null);
    }
  };

  const translateEbook = async (targetLang: string) => {
    if (!currentProject?.id || !currentChapters.length) return;
    setIsTranslating(true);
    setShowTranslationModal(false);
    const langName = LANGUAGES.find(l => l.code === targetLang)?.name;
    
    setProcessState({
      isVisible: true,
      title: "Translating Ebook",
      message: `Preparing to translate to ${langName}...`,
      progress: 0,
      steps: currentChapters.map((ch, i) => ({ label: `Chapter ${i + 1}`, status: 'pending' }))
    });

    try {
      for (let i = 0; i < currentChapters.length; i++) {
        const chapter = currentChapters[i];
        
        setProcessState(prev => prev ? {
          ...prev,
          progress: Math.round((i / currentChapters.length) * 100),
          message: `Translating Chapter ${i + 1}: ${chapter.title}...`,
          steps: prev.steps?.map((s, idx) => ({
            ...s,
            status: idx === i ? 'active' : idx < i ? 'complete' : 'pending'
          }))
        } : null);
        
        // Fetch original content
        const response = await fetch(chapter.contentUrl);
        const originalContent = await response.text();

        // Translate using AI
        const translation = await translateChapter(chapter.title, originalContent, targetLang);
        
        // Translate summary if it exists
        let translatedSummary = "";
        if (chapter.summary) {
          const summaryTranslation = await translateChapter(chapter.title + " Summary", chapter.summary, targetLang);
          translatedSummary = summaryTranslation.content;
        }

        // Upload translated content to Storage
        const fileName = `chapter_${chapter.index}_${targetLang}.md`;
        const storageRef = ref(storage, `projects/${currentProject.id}/chapters/${fileName}`);
        await uploadString(storageRef, translation.content);
        const translatedContentUrl = await getDownloadURL(storageRef);

        // Update Firestore
        const translations = { ...(chapter.translations || {}) };
        translations[targetLang] = {
          title: String(translation.title || "Untitled Translation").substring(0, 199),
          contentUrl: translatedContentUrl,
          summary: String(translatedSummary || "").substring(0, 999)
        };

        await updateDoc(doc(db, 'projects', currentProject.id!, 'chapters', chapter.id!), {
          translations,
          updatedAt: serverTimestamp()
        });
      }
      
      setProcessState(prev => prev ? {
        ...prev,
        progress: 100,
        message: "Translation complete!",
        steps: prev.steps?.map(s => ({ ...s, status: 'complete' }))
      } : null);

      await updateDoc(doc(db, 'projects', currentProject.id!), {
        isTranslated: true,
        updatedAt: serverTimestamp()
      });
      setCurrentProject(prev => prev ? { ...prev, isTranslated: true } : null);

      setSelectedLanguage(targetLang);
      toast.success(`Ebook translated to ${langName} successfully!`);
      await new Promise(r => setTimeout(r, 800));
    } catch (err) {
      handleAIError(err, "Translation");
    } finally {
      setIsTranslating(false);
      setProcessState(null);
    }
  };

  const generateCover = async () => {
    if (!currentProject?.id || isGenerating || !coverStyles.length) return;
    setIsGenerating(true);
    
    setProcessState({
      isVisible: true,
      title: "Designing Cover Art",
      message: "Analyzing keywords and styles...",
      progress: 0,
      steps: coverStyles.map(style => ({ label: `Generating ${style} variation`, status: 'pending' }))
    });

    try {
      const urls: string[] = [];
      for (let i = 0; i < coverStyles.length; i++) {
        const style = coverStyles[i];
        
        setProcessState(prev => prev ? {
          ...prev,
          progress: Math.round((i / coverStyles.length) * 100),
          message: `Designing ${style} variation...`,
          steps: prev.steps?.map((s, idx) => ({
            ...s,
            status: idx === i ? 'active' : idx < i ? 'complete' : 'pending'
          }))
        } : null);

        const url = await generateCoverArt(currentProject.title, currentProject.niche, coverKeywords, style);
        if (url) {
          // url is a base64 data URL. We MUST upload it to Storage to avoid the 1MB Firestore doc limit
          const storageRef = ref(storage, `projects/${currentProject.id}/covers/cover_${Date.now()}_${i}.png`);
          await uploadString(storageRef, url, 'data_url');
          const downloadUrl = await getDownloadURL(storageRef);
          urls.push(downloadUrl);
        }
      }

      if (urls.length > 0) {
        setProcessState(prev => prev ? {
          ...prev,
          progress: 90,
          message: "Saving covers to project...",
          steps: prev.steps?.map(s => ({ ...s, status: 'complete' }))
        } : null);

        await updateDoc(doc(db, 'projects', currentProject.id!), {
          coverUrls: urls,
          coverUrl: urls[0], // Set the first one as default
          updatedAt: serverTimestamp()
        });
        setCurrentProject(prev => prev ? { ...prev, coverUrls: urls, coverUrl: urls[0] } : null);
        
        setProcessState(prev => prev ? { ...prev, progress: 100, message: "Cover art generated!" } : null);
        await new Promise(r => setTimeout(r, 800));
      } else {
        throw new Error("AI failed to generate cover images.");
      }
    } catch (err) {
      handleAIError(err, "Cover generation");
      setError(formatError(err, "Cover generation"));
    } finally {
      setIsGenerating(false);
      setProcessState(null);
    }
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentProject?.id) return;

    setIsGenerating(true);
    setGenerationProgress("Uploading cover image...");

    try {
      if (file.size > 5 * 1024 * 1024) throw new Error("File too large. Max 5MB.");
      if (!file.type.startsWith('image/')) throw new Error("Invalid file type. Please upload an image.");

      const storageRef = ref(storage, `projects/${currentProject.id}/cover_${Date.now()}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);

      await updateDoc(doc(db, 'projects', currentProject.id!), {
        coverUrl: url,
        updatedAt: serverTimestamp()
      });
      setCurrentProject(prev => prev ? { ...prev, coverUrl: url } : null);
    } catch (err) {
      setError(formatError(err, "Cover upload"));
    } finally {
      setIsGenerating(false);
    }
  };

  const publishEbook = async (platforms: string[], pricing: number, formatting: { fontFamily: string, lineSpacing: number, fontSize: number, textAlign: string }) => {
    if (!currentProject?.id) return;
    setIsGenerating(true);
    setGenerationProgress("Submitting to marketplaces...");

    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: currentProject.id,
          platforms,
          metadata: { title: currentProject.title, pricing, formatting }
        })
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || `Server error: ${res.status}`);
      }

      const data = await res.json();
      if (data.success) {
        await updateDoc(doc(db, 'projects', currentProject.id!), {
          status: 'published',
          pricing,
          formatting,
          platforms: platforms.reduce((acc: any, p) => ({ ...acc, [p]: true }), {}),
          updatedAt: serverTimestamp()
        });
        setStep('done');
      }
    } catch (err) {
      setError(formatError(err, "Publishing"));
    } finally {
      setIsGenerating(false);
    }
  };

  const executeExport = async () => {
    if (!currentProject?.id || !currentChapters.length) {
      toast.error("No content to export. Please generate chapters first.");
      return;
    }
    
    setIsExporting(true);
    setGenerationProgress(`Packaging your ${exportFormat.toUpperCase()}...`);
    toast.info(`Generating your ${exportFormat.toUpperCase()}...`);
    setShowExportModal(false);
    
    try {
      if (exportFormat === 'zip') {
        await exportToZip(currentProject, currentChapters, selectedLanguage);
      } else if (exportFormat === 'epub') {
        await exportToEpub(currentProject, currentChapters, selectedLanguage);
      } else if (exportFormat === 'pdf') {
        await exportToPdf(currentProject, currentChapters, selectedLanguage, { 
          pageSize: exportPageSize,
          includeCover: exportIncludeCover
        });
      }
      toast.success(`${exportFormat.toUpperCase()} exported successfully!`);
    } catch (err) {
      const msg = formatError(err, "Export");
      toast.error(msg);
    } finally {
      setIsExporting(false);
      setGenerationProgress("");
    }
  };

  const exportAllChapters = async () => {
    if (!currentProject?.id || !currentChapters.length) return;
    setIsExporting(true);
    setGenerationProgress("Zipping all chapters for download...");
    try {
      const zip = new JSZip();
      const langName = LANGUAGES.find(l => l.code === selectedLanguage)?.name || 'English';
      const folder = zip.folder(`${currentProject.title}_chapters_${langName.toLowerCase()}`);
      
      const chapterContents = await Promise.all(currentChapters.map(async (ch) => {
        const url = selectedLanguage === 'en' 
          ? ch.contentUrl 
          : ch.translations?.[selectedLanguage]?.contentUrl;
        
        if (!url) return null;

        const response = await fetch(url);
        const text = await response.text();
        const title = selectedLanguage === 'en' 
          ? ch.title 
          : (ch.translations?.[selectedLanguage]?.title || ch.title);
        return { title, content: text, index: ch.index };
      }));

      chapterContents.forEach((ch) => {
        if (ch) {
          folder?.file(`Chapter_${ch.index + 1}_${ch.title.replace(/[^a-z0-9]/gi, '_')}.md`, ch.content);
        }
      });

      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = `${currentProject.title}_Chapters_${langName.toLowerCase()}.zip`;
      link.click();
      toast.success(`All chapters (${langName}) exported as individual .md files in a ZIP archive.`);
    } catch (err) {
      toast.error("Failed to export chapters: " + (err as Error).message);
    } finally {
      setIsExporting(false);
      setGenerationProgress("");
    }
  };

  const deleteProject = async (id: string) => {
    if (confirm("Are you sure you want to delete this project?")) {
      try {
        const chaptersSnapshot = await getDocs(collection(db, 'projects', id, 'chapters'));
        
        // Delete from Storage and Firestore
        const deletePromises = chaptersSnapshot.docs.map(async (chapterDoc) => {
          const data = chapterDoc.data();
          if (data.contentUrl) {
            try {
              const storageRef = ref(storage, data.contentUrl);
              await deleteObject(storageRef);
            } catch (e) {
              console.warn("Could not delete storage object:", e);
            }
          }
          return deleteDoc(chapterDoc.ref);
        });
        
        await Promise.all(deletePromises);
        await deleteDoc(doc(db, 'projects', id));
      } catch (err) {
        console.error("Delete failed:", err);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center space-y-8"
        >
          <div className="space-y-2">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-slate-900 tracking-tight">EbookForge</h1>
            <p className="text-slate-500">Turn your ideas into publish-ready ebooks in minutes.</p>
          </div>
          <Button 
            onClick={login}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 text-lg shadow-md"
          >
            Sign in with Google
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      <GlobalLoadingBar 
        isVisible={isGenerating || isTranslating || isExporting} 
        progress={isGenerating ? generationPercent : undefined}
        status={generationProgress || (isTranslating ? "Translating Ebook..." : isExporting ? "Exporting Ebook..." : "")}
      />

      {processState && (
        <FullScreenProcessOverlay
          isVisible={processState.isVisible}
          title={processState.title}
          message={processState.message}
          progress={processState.progress}
          steps={processState.steps}
        />
      )}
      
      {dbError && (
        <div className="bg-red-600 text-white p-3 text-center text-sm font-bold flex items-center justify-center gap-3 animate-in fade-in slide-in-from-top duration-500">
          <AlertTriangle className="w-5 h-5" />
          <span>Database connection issues detected. Please check your internet connection or refresh the page.</span>
          <button onClick={() => window.location.reload()} className="bg-white text-red-600 px-3 py-1 rounded-lg text-xs hover:bg-red-50 transition-colors shadow-sm">
            Refresh App
          </button>
        </div>
      )}

      {/* Header */}
      <header className="bg-[#11131C] border-b border-[#232738] sticky top-0 z-40 text-slate-100">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          
          {/* Brand Logo & View Tabs */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => { setCurrentView('storefront'); setStep('list'); }}>
              <div className="w-8 h-8 rounded-lg bg-[#201D13] border border-[#584B28] flex items-center justify-center text-[#E5C158] font-serif font-bold text-base shadow-sm">
                E
              </div>
              <div>
                <span className="text-lg font-serif font-bold tracking-tight text-white block leading-none">EbookFactory</span>
                <span className="text-[9px] text-[#E5C158] uppercase tracking-widest font-sans font-semibold">SaaS & Marketplace</span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-[#181B28] p-1 rounded-xl border border-[#2B3045]">
              <button
                onClick={() => setCurrentView('storefront')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentView === 'storefront' ? 'bg-[#E5C158] text-black shadow-md' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Store className="w-3.5 h-3.5" />
                Storefront
              </button>

              {isAdmin && (
                <>
                  <button
                    onClick={() => setCurrentView('creator')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      currentView === 'creator' ? 'bg-[#E5C158] text-black shadow-md' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Creator Studio
                  </button>
                  <button
                    onClick={() => setCurrentView('niche')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      currentView === 'niche' ? 'bg-[#E5C158] text-black shadow-md' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    <Compass className="w-3.5 h-3.5" />
                    NicheMaster AI
                  </button>
                </>
              )}

              <button
                onClick={() => setCurrentView('library')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentView === 'library' ? 'bg-[#E5C158] text-black shadow-md' : 'text-slate-300 hover:text-white'
                }`}
              >
                <BookMarked className="w-3.5 h-3.5" />
                My Library
              </button>
            </nav>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-3">
            {currentProject?.id && currentView === 'creator' && step !== 'list' && step !== 'done' && isAdmin && (
              <div className="hidden lg:flex items-center gap-2">
                <Button 
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="bg-[#181B28] border border-[#2B3045] text-slate-200 hover:text-[#E5C158] shadow-sm py-1.5 h-8 text-xs"
                >
                  {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  <span>Save Draft</span>
                </Button>
                <Button 
                  onClick={() => setShowExportModal(true)}
                  disabled={isExporting}
                  className="bg-[#D4AF37] text-black font-semibold shadow-sm py-1.5 h-8 text-xs"
                >
                  {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                  <span>Export</span>
                </Button>
              </div>
            )}

            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 rounded-xl bg-[#181B28] border border-[#2B3045] text-slate-200 hover:border-[#E5C158] transition-all cursor-pointer"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-4 h-4 text-[#E5C158]" />
              {cart.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-[#D4AF37] text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </button>

            {isAdmin && (
              <div
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#201D13] border border-[#584B28] text-[#E5C158] text-xs font-semibold"
                title="Admin Status Active"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Admin</span>
              </div>
            )}

            {user && (
              <div className="hidden sm:flex items-center gap-2 text-xs text-slate-300 bg-[#161924] px-2.5 py-1 rounded-xl border border-[#282D42]">
                <img src={user.photoURL || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"} alt="" className="w-5 h-5 rounded-full border border-slate-600" />
                <span className="font-medium max-w-[90px] truncate">{user.displayName || "Customer"}</span>
              </div>
            )}

            <Button 
              onClick={() => setShowSettings(true)} 
              className="text-slate-400 hover:text-white p-2 bg-[#181B28] border border-[#2B3045]"
              aria-label="User Settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
            {user && (
              <Button 
                onClick={logout} 
                className="text-slate-400 hover:text-red-400 p-2 bg-[#181B28] border border-[#2B3045]"
                aria-label="Logout"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex items-center justify-around border-t border-[#232738] bg-[#0E1018] py-2 text-xs">
          <button
            onClick={() => setCurrentView('storefront')}
            className={`flex items-center gap-1 ${currentView === 'storefront' ? 'text-[#E5C158] font-bold' : 'text-slate-400'}`}
          >
            <Store className="w-3.5 h-3.5" />
            Store
          </button>
          {isAdmin && (
            <>
              <button
                onClick={() => setCurrentView('creator')}
                className={`flex items-center gap-1 ${currentView === 'creator' ? 'text-[#E5C158] font-bold' : 'text-slate-400'}`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                Studio
              </button>
              <button
                onClick={() => setCurrentView('niche')}
                className={`flex items-center gap-1 ${currentView === 'niche' ? 'text-[#E5C158] font-bold' : 'text-slate-400'}`}
              >
                <Compass className="w-3.5 h-3.5" />
                Niche
              </button>
            </>
          )}
          <button
            onClick={() => setCurrentView('library')}
            className={`flex items-center gap-1 ${currentView === 'library' ? 'text-[#E5C158] font-bold' : 'text-slate-400'}`}
          >
            <BookMarked className="w-3.5 h-3.5" />
            Library
          </button>
        </div>
      </header>

      {/* Main View Router */}
      {currentView === 'storefront' && (
        <Storefront
          onSelectProduct={(p) => handleAddToCart(p)}
          onAddToCart={handleAddToCart}
          onOpenCart={() => setIsCartOpen(true)}
          onLaunchCreatorStudio={() => {
            if (isAdmin) {
              setCurrentView('creator');
              setStep('list');
            }
          }}
          onNavigateToNiche={() => {
            if (isAdmin) {
              setCurrentView('niche');
            }
          }}
          cartCount={cart.length}
          isAdmin={isAdmin}
        />
      )}

      {currentView === 'niche' && (
        isAdmin ? (
          <NicheIntelligence
            onTurnNicheIntoProject={handleTurnNicheIntoProject}
          />
        ) : (
          <AccessDeniedView
            featureName="NicheMaster AI Hub"
            onGoToStorefront={() => setCurrentView('storefront')}
          />
        )
      )}

      {currentView === 'library' && (
        <MyLibrary
          orders={orders}
          onNavigateToStorefront={() => setCurrentView('storefront')}
        />
      )}

      {currentView === 'creator' && (
        isAdmin ? (
          <main className="max-w-5xl mx-auto p-4 py-8">

        <AnimatePresence mode="wait">
          {step === 'list' && (
            <motion.div 
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold tracking-tight dark:text-white">Your Projects</h2>
                  <p className="text-slate-500 dark:text-slate-400">Manage and create your high-value ebooks.</p>
                </div>
                <Button onClick={createNewProject} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                  <Plus className="w-5 h-5" />
                  New Ebook
                </Button>
              </div>

              {projects.length === 0 ? (
                <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800">
                  <BookOpen className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white">No ebooks yet</h3>
                  <p className="text-slate-500 dark:text-slate-400 mb-6">Start by picking a high-performing niche.</p>
                  <Button onClick={createNewProject} className="bg-indigo-600 text-white mx-auto">
                    Create your first ebook
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {projects.map((p) => (
                    <Card key={p.id} className="hover:shadow-md transition-shadow group">
                      <div className="p-6 space-y-4">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1">
                            <h3 className="font-bold text-lg line-clamp-1 dark:text-white">{p.title}</h3>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{p.niche}</p>
                          </div>
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                            p.status === 'published' ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400" : "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
                          )}>
                            {p.status}
                          </span>
                        </div>

                        <ProjectProgress project={p} />

                        {p.marketplaceLinks && Object.values(p.marketplaceLinks).some(link => link) && (
                          <div className="flex gap-2 pt-2">
                            {p.marketplaceLinks.amazon && (
                              <a href={p.marketplaceLinks.amazon} target="_blank" rel="noopener noreferrer" className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors" title="Amazon Listing">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon" className="w-3.5 h-3.5 object-contain" referrerPolicy="no-referrer" />
                              </a>
                            )}
                            {p.marketplaceLinks.apple && (
                              <a href={p.marketplaceLinks.apple} target="_blank" rel="noopener noreferrer" className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors" title="Apple Books Listing">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" alt="Apple" className="w-3.5 h-3.5 object-contain" referrerPolicy="no-referrer" />
                              </a>
                            )}
                            {p.marketplaceLinks.google && (
                              <a href={p.marketplaceLinks.google} target="_blank" rel="noopener noreferrer" className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors" title="Google Play Books Listing">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/d/d0/Google_Play_Arrow_logo.svg" alt="Google" className="w-3.5 h-3.5 object-contain" referrerPolicy="no-referrer" />
                              </a>
                            )}
                            {p.marketplaceLinks.other && (
                              <a href={p.marketplaceLinks.other} target="_blank" rel="noopener noreferrer" className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors" title="Other Listing">
                                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                              </a>
                            )}
                          </div>
                        )}

                        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                          <div className="text-xs text-slate-400 dark:text-slate-500">
                            Updated {new Date(p.updatedAt?.seconds * 1000).toLocaleDateString()}
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              onClick={() => {
                                setCurrentProject(p);
                                setShowCollaboratorsModal(true);
                              }}
                              className="p-2 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400"
                              title="Collaborators"
                              aria-label="Manage Collaborators"
                            >
                              <Users className="w-4 h-4" />
                            </Button>
                            <Button 
                              onClick={() => {
                                setCurrentProject(p);
                                setShowProjectDetails(true);
                              }}
                              className="p-2 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400"
                              title="Project Details"
                              aria-label="Project Details"
                            >
                              <Settings className="w-4 h-4" />
                            </Button>
                            <Button 
                              onClick={() => setProjectToDelete(p)}
                              className="p-2 text-slate-500 hover:text-red-600 dark:hover:text-red-400"
                              aria-label="Delete Project"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                            <Button 
                              onClick={() => {
                                setCurrentProject(p);
                                setStep(p.status === 'published' ? 'done' : 'upload');
                              }}
                              className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                            >
                              Continue
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {step === 'template' && (
            <motion.div 
              key="template"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2 text-center max-w-2xl mx-auto">
                <h2 className="text-3xl font-bold tracking-tight dark:text-white">Choose Your Ebook Template</h2>
                <p className="text-slate-500 dark:text-slate-400">Select a template to pre-configure your writing style and formatting for the best results.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                {[...PROJECT_TEMPLATES, ...customTemplates].map((t) => {
                  const Icon = IconMap[t.icon] || BookOpen;
                  return (
                    <button 
                      key={t.id}
                      id={`template-btn-${t.id}`}
                      onClick={() => selectTemplate(t)}
                      className="text-left p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-600 dark:hover:border-indigo-500 hover:shadow-xl transition-all group relative overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Icon className="w-24 h-24" />
                      </div>
                      <div className="relative z-10 space-y-4">
                        <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                          <Icon className="w-6 h-6" />
                        </div>
                        <div className="space-y-1">
                          <h3 className="font-bold text-xl dark:text-white">
                            {t.name}
                            {t.id.startsWith('custom-') && <span className="ml-2 text-xs bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full font-semibold">Custom</span>}
                          </h3>
                          <p className="text-sm text-slate-500 dark:text-slate-400">{t.description}</p>
                        </div>
                        <div className="pt-4 flex items-center text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">
                          Select Template <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </button>
                  );
                })}

                <button 
                  onClick={() => setShowCustomTemplateModal(true)}
                  className="text-center p-8 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-500 hover:bg-white dark:hover:bg-slate-800 transition-all group flex flex-col items-center justify-center min-h-[280px]"
                >
                  <div className="w-12 h-12 bg-white dark:bg-slate-700 rounded-full flex items-center justify-center text-slate-400 group-hover:text-indigo-500 shadow-sm mb-4 transition-colors">
                    <span className="text-2xl font-light">+</span>
                  </div>
                  <h3 className="font-bold text-lg text-slate-700 dark:text-slate-300 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">Create Custom Template</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Design your own blueprint with specialized writing styles and tones.</p>
                </button>
              </div>
              
              <div className="text-center">
                <Button 
                  onClick={() => setStep('list')} 
                  className="text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                  aria-label="Cancel and return to dashboard"
                >
                  Cancel and go back
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'niche' && (
            <motion.div 
              key="niche"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <Button onClick={() => setStep('template')} className="text-slate-500 dark:text-slate-400 p-0 hover:text-indigo-600 dark:hover:text-indigo-400">
                  <ArrowLeft className="w-4 h-4" /> Back to templates
                </Button>
                <h2 className="text-3xl font-bold tracking-tight dark:text-white">Select a High-Value Niche</h2>
                <p className="text-slate-500 dark:text-slate-400">
                  {selectedTemplate 
                    ? `Recommended for your ${selectedTemplate.name} template.` 
                    : "Choose from top-performing markets based on current KDP trends."}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  ...(selectedTemplate && !showAllNiches
                    ? TOP_NICHES.filter(n => selectedTemplate.suggestedNiches.includes(n.id))
                    : TOP_NICHES),
                  ...discoveredNiches
                ].map((n) => (
                  <button 
                    key={n.id}
                    id={`niche-btn-${n.id}`}
                    onClick={() => selectNiche(n)}
                    className="text-left p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-600 dark:hover:border-indigo-500 hover:shadow-lg transition-all group"
                  >
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <h3 className="font-bold text-lg group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors dark:text-white">{n.title}</h3>
                        {selectedTemplate?.suggestedNiches.includes(n.id) && (
                          <div className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-[10px] font-black uppercase tracking-widest rounded-full shadow-sm">
                            Recommended
                          </div>
                        )}
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider">Potential</span>
                          <span className={cn(
                            "font-bold",
                            n.potential === 'High' ? "text-green-600 dark:text-green-400" : "text-amber-600 dark:text-amber-400"
                          )}>{n.potential}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider">Competition</span>
                          <span className={cn(
                            "font-bold",
                            n.competition === 'Low' ? "text-green-600 dark:text-green-400" : n.competition === 'Medium' ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400"
                          )}>{n.competition}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider">Time to Market</span>
                          <span className="text-indigo-600 dark:text-indigo-400 font-bold">{n.timeToMarket}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {selectedTemplate && (
                <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-wrap justify-center gap-4">
                  <div className="w-full text-center mb-2">
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      {showAllNiches 
                        ? "Showing all available high-value niches." 
                        : `Only showing niches optimized for ${selectedTemplate.name}.`}
                    </p>
                  </div>
                  <Button 
                    onClick={() => setShowAllNiches(!showAllNiches)}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-indigo-600"
                  >
                    {showAllNiches ? "Show Recommended Only" : "Show All Niches"}
                  </Button>
                  <Button 
                    onClick={handleDiscoverTrends}
                    disabled={isAnalyzingTrends}
                    className="bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/30 font-bold"
                  >
                    {isAnalyzingTrends ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <TrendingUp className="w-4 h-4 mr-2" />}
                    Discover Real-Time Trends
                  </Button>
                </div>
              )}
            </motion.div>
          )}

          {step === 'upload' && (
            <motion.div 
              key="upload"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto space-y-8"
            >
              <div className="text-center space-y-2">
                <h2 className="text-3xl font-bold tracking-tight dark:text-white">Add Your Content</h2>
                <p className="text-slate-500 dark:text-slate-400">Upload raw notes, voice transcripts, or start from scratch.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <label className="cursor-pointer p-8 bg-white dark:bg-slate-900 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl hover:border-indigo-600 dark:hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all text-center space-y-4">
                  <input type="file" className="hidden" accept=".txt,.md" onChange={handleUpload} />
                  <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto">
                    <FileText className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div>
                    <h4 className="font-bold dark:text-white">Upload Text</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">.txt, .md files</p>
                  </div>
                </label>

                <div className="p-8 bg-white dark:bg-slate-900 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl opacity-50 cursor-not-allowed text-center space-y-4">
                  <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto">
                    <Mic className="w-6 h-6 text-slate-400 dark:text-slate-600" />
                  </div>
                  <div>
                    <h4 className="font-bold dark:text-white">Voice Upload</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Coming Soon</p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="flex items-center gap-4 my-4 text-slate-300 dark:text-slate-700">
                  <div className="h-px bg-slate-200 dark:bg-slate-800 flex-1" />
                  <span className="text-xs font-bold uppercase tracking-widest">Or</span>
                  <div className="h-px bg-slate-200 dark:bg-slate-800 flex-1" />
                </div>
                <Button 
                  onClick={startGeneration}
                  disabled={isGenerating}
                  className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-black dark:hover:bg-slate-200 py-4"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Forging Content...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 text-amber-400" />
                      Generate from Niche Only
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'outline' && (
            <motion.div 
              key="outline"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold tracking-tight">Review Ebook Outline</h2>
                  <p className="text-slate-500">Drag to reorder chapters or customize titles and descriptions.</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex flex-col items-end">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Writing Style</label>
                    <select 
                      value={writingStyle}
                      onChange={(e) => setWritingStyle(e.target.value)}
                      className="p-2 bg-white border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
                    >
                      <option value="conversational">Conversational</option>
                      <option value="formal">Formal</option>
                      <option value="academic">Academic</option>
                      <option value="storytelling">Storytelling</option>
                      <option value="technical">Technical</option>
                      <option value="humorous">Humorous</option>
                    </select>
                  </div>
                  <Button onClick={generateFullContent} className="bg-indigo-600 text-white shadow-lg shadow-indigo-200">
                    <Sparkles className="w-5 h-5" />
                    Generate Full Content
                  </Button>
                </div>
              </div>

              <Reorder.Group 
                axis="y" 
                values={editableOutline} 
                onReorder={setEditableOutline}
                className="space-y-4"
              >
                {editableOutline.map((ch, idx) => (
                  <Reorder.Item 
                    key={ch.title + idx} 
                    value={ch}
                    className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-200 transition-all space-y-4 relative group"
                    whileDrag={{ scale: 1.02, boxShadow: "0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)" }}
                  >
                    <div className="flex items-center gap-4">
                      <div className="cursor-grab active:cursor-grabbing p-1 hover:bg-slate-100 rounded text-slate-400">
                        <GripVertical className="w-5 h-5" />
                      </div>
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm shrink-0">
                        {idx + 1}
                      </div>
                      <input 
                        value={ch.title}
                        onChange={(e) => {
                          const newOutline = [...editableOutline];
                          newOutline[idx].title = e.target.value;
                          setEditableOutline(newOutline);
                        }}
                        className="flex-1 text-xl font-bold bg-transparent border-b border-transparent hover:border-slate-200 focus:border-indigo-500 outline-none transition-colors"
                        placeholder="Chapter Title"
                      />
                      <select 
                        value={ch.writingStyle || writingStyle}
                        onChange={(e) => {
                          const newOutline = [...editableOutline];
                          newOutline[idx].writingStyle = e.target.value;
                          setEditableOutline(newOutline);
                        }}
                        className="text-xs font-bold bg-slate-100 border border-slate-200 rounded px-2 py-1 outline-none text-slate-600"
                      >
                        <option value="conversational">Conversational</option>
                        <option value="formal">Formal</option>
                        <option value="academic">Academic</option>
                        <option value="storytelling">Storytelling</option>
                        <option value="technical">Technical</option>
                        <option value="persuasive">Persuasive</option>
                      </select>
                      <select 
                        onChange={(e) => applyChapterTemplate(idx, e.target.value)}
                        value=""
                        className="text-xs font-bold bg-indigo-50 border border-indigo-100 text-indigo-600 rounded px-2 py-1 outline-none cursor-pointer hover:bg-indigo-100 transition-colors"
                      >
                        <option value="" disabled>Apply Template</option>
                        {CHAPTER_TEMPLATES.map(template => (
                          <option key={template.id} value={template.id}>{template.title}</option>
                        ))}
                      </select>
                      <Button 
                        onClick={() => {
                          const newOutline = editableOutline.filter((_, i) => i !== idx);
                          setEditableOutline(newOutline);
                        }}
                        className="text-slate-400 hover:text-red-500 p-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <textarea 
                      value={ch.description}
                      onChange={(e) => {
                        const newOutline = [...editableOutline];
                        newOutline[idx].description = e.target.value;
                        setEditableOutline(newOutline);
                      }}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none h-24 resize-none text-slate-600"
                      placeholder="What should this chapter cover?"
                    />
                  </Reorder.Item>
                ))}
              </Reorder.Group>
              
              <Button 
                onClick={() => setEditableOutline([...editableOutline, { title: "New Chapter", description: "" }])}
                className="w-full py-4 border-2 border-dashed border-slate-200 text-slate-400 hover:text-indigo-600 hover:border-indigo-200 hover:bg-indigo-50/50 transition-all"
              >
                <Plus className="w-5 h-5" />
                Add Another Chapter
              </Button>

              <div className="flex justify-end gap-4">
                <Button onClick={exportOutline} className="bg-white border border-slate-200 text-slate-600 hover:bg-slate-50">
                  <Download className="w-4 h-4" />
                  Export JSON
                </Button>
                <Button onClick={startGeneration} className="bg-slate-100 text-slate-700">
                  Regenerate Outline
                </Button>
                <Button onClick={() => setStep('niche')} className="bg-slate-100 text-slate-700">
                  Back to Niches
                </Button>
                <Button onClick={generateFullContent} className="bg-indigo-600 text-white px-8">
                  Start AI Content Forge
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'generate' && (
            <motion.div 
              key="generate"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-7xl mx-auto py-8"
            >
              {isGenerating ? (
                <div className="max-w-3xl mx-auto space-y-12">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-indigo-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                      <Sparkles className="w-10 h-10 text-indigo-600 animate-pulse" />
                    </div>
                    <h2 className="text-4xl font-bold tracking-tight">Forging your Ebook...</h2>
                    <p className="text-slate-500 text-lg max-w-md mx-auto">Our AI is crafting high-value content for each chapter. This may take a few minutes.</p>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl space-y-8">
                      <div className="space-y-4">
                        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-indigo-600"
                            initial={{ width: 0 }}
                            animate={{ width: `${generationPercent}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-widest">
                          <span>Progress</span>
                          <span>{generationPercent}%</span>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {editableOutline.map((ch, idx) => (
                          <div key={idx} className="flex items-center justify-between p-4 rounded-xl border border-slate-100 bg-slate-50/50">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold",
                                chapterStatuses[idx] === 'complete' ? "bg-green-100 text-green-600" : 
                                chapterStatuses[idx] === 'generating' || chapterStatuses[idx] === 'saving' ? "bg-indigo-100 text-indigo-600" : "bg-slate-200 text-slate-400"
                              )}>
                                {chapterStatuses[idx] === 'complete' ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                              </div>
                              <span className={cn(
                                "font-medium",
                                chapterStatuses[idx] === 'complete' ? "text-slate-900" : "text-slate-500"
                              )}>{ch.title}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {chapterStatuses[idx] === 'generating' && (
                                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-600 flex items-center gap-1">
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                  Generating
                                </span>
                              )}
                              {chapterStatuses[idx] === 'saving' && (
                                <span className="text-[10px] font-bold uppercase tracking-widest text-amber-600 flex items-center gap-1">
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                  Saving
                                </span>
                              )}
                              {chapterStatuses[idx] === 'complete' && (
                                <span className="text-[10px] font-bold uppercase tracking-widest text-green-600">Complete</span>
                              )}
                              {chapterStatuses[idx] === 'pending' && (
                                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Pending</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : currentChapters.length > 0 ? (
                <div className="flex flex-col lg:flex-row gap-8">
                  {/* Sidebar Navigation */}
                  <div className="lg:w-80 shrink-0 space-y-6">
                    <Card className="p-6 sticky top-24">
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <div className="flex justify-between items-end">
                            <h3 className="font-bold text-slate-900">Review Progress</h3>
                            <span className="text-xs font-bold text-indigo-600">{Math.round((currentChapters.filter(ch => ch.isReviewed).length / currentChapters.length) * 100)}%</span>
                          </div>
                          <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                            <motion.div 
                              className="h-full bg-indigo-600"
                              initial={{ width: 0 }}
                              animate={{ width: `${(currentChapters.filter(ch => ch.isReviewed).length / currentChapters.length) * 100}%` }}
                            />
                          </div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                            {currentChapters.filter(ch => ch.isReviewed).length} of {currentChapters.length} Chapters Reviewed
                          </p>
                        </div>

                        <div className="space-y-4 pt-4 border-t border-slate-100">
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Chapters</h4>
                          <div className="space-y-1">
                            {currentChapters.map((ch, idx) => (
                              <button
                                key={ch.id}
                                onClick={() => {
                                  const element = document.getElementById(`chapter-${ch.id}`);
                                  if (element) {
                                    const headerOffset = 100;
                                    const elementPosition = element.getBoundingClientRect().top;
                                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                                    window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                                  }
                                }}
                                className={cn(
                                  "w-full flex items-center justify-between p-3 rounded-xl text-sm transition-all group",
                                  "hover:bg-slate-50"
                                )}
                              >
                                <div className="flex items-center gap-3 min-w-0">
                                  <div className={cn(
                                    "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0",
                                    ch.isReviewed ? "bg-green-100 text-green-600" : "bg-slate-100 text-slate-400"
                                  )}>
                                    {idx + 1}
                                  </div>
                                  <span className={cn(
                                    "truncate font-medium",
                                    ch.isReviewed ? "text-slate-400 line-through" : "text-slate-600"
                                  )}>
                                    {selectedLanguage === 'en' ? ch.title : (ch.translations?.[selectedLanguage]?.title || ch.title)}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  {ch.factCheck && (
                                    <div className={cn(
                                      "p-1 rounded-full",
                                      ch.factCheck.claims.some(c => c.status === 'inaccurate') ? "bg-red-100 text-red-600" :
                                      ch.factCheck.claims.some(c => c.status === 'partially_accurate') ? "bg-amber-100 text-amber-600" :
                                      "bg-emerald-100 text-emerald-600"
                                    )} title="Fact-Check Status">
                                      <ShieldCheck className="w-3 h-3" />
                                    </div>
                                  )}
                                  <span className="text-[10px] font-bold text-slate-300 group-hover:text-slate-400 transition-colors">
                                    {chapterWordCounts[ch.id!] || 0}w
                                  </span>
                                  {ch.isReviewed && <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />}
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="pt-4 border-t border-slate-100 space-y-3">
                          <Button 
                            onClick={exportAllChapters}
                            disabled={isExporting}
                            className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm"
                          >
                            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                            Export All (.md)
                          </Button>
                          <Button 
                            onClick={() => setShowPreview(true)}
                            className="w-full bg-indigo-50 text-indigo-600 hover:bg-indigo-100 text-sm"
                          >
                            <Eye className="w-4 h-4" />
                            Preview Ebook
                          </Button>
                          <Button 
                            onClick={() => setShowProjectDetails(true)}
                            className="w-full bg-slate-50 text-slate-600 hover:bg-slate-100 text-sm border border-slate-100"
                          >
                            <ExternalLink className="w-4 h-4" />
                            Marketplace Links
                          </Button>
                        </div>
                      </div>
                    </Card>
                  </div>

                  {/* Main Content Area */}
                  <div className="flex-1 space-y-8">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-20 z-10">
                      <div>
                        <h2 className="text-2xl font-bold text-slate-900">Review Chapters</h2>
                        <p className="text-sm text-slate-500">Edit content, check grammar, and mark as reviewed.</p>
                      </div>
                      <div className="flex flex-wrap gap-3">
                        <div className="flex items-center bg-slate-100 rounded-lg px-2 border border-slate-200">
                          <Languages className="w-4 h-4 text-slate-400 mr-2" />
                          <select 
                            value={selectedLanguage}
                            onChange={(e) => setSelectedLanguage(e.target.value)}
                            className="bg-transparent text-sm font-medium outline-none py-2"
                          >
                            {LANGUAGES.map(lang => (
                              <option key={lang.code} value={lang.code}>{lang.name}</option>
                            ))}
                          </select>
                        </div>
                        <Button 
                          onClick={() => setShowTranslationModal(true)}
                          disabled={isTranslating}
                          className="bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-200 shadow-sm"
                        >
                          {isTranslating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Languages className="w-4 h-4" />}
                          Translate AI
                        </Button>
                        <Button 
                          onClick={() => setShowExportModal(true)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Export Ebook
                        </Button>
                      </div>
                    </div>

                    <Reorder.Group 
                      axis="y" 
                      values={currentChapters} 
                      onReorder={async (newChapters) => {
                        setCurrentChapters(newChapters);
                        if (currentProject?.id) {
                          try {
                            await Promise.all(newChapters.map((ch, idx) => 
                              updateDoc(doc(db, 'projects', currentProject.id!, 'chapters', ch.id), { index: idx })
                            ));
                          } catch (err) {
                            console.error("Failed to update chapter order:", err);
                          }
                        }
                      }}
                      className="space-y-8"
                    >
                      {currentChapters.map((ch) => (
                        <Reorder.Item 
                          key={ch.id} 
                          value={ch}
                          id={`chapter-${ch.id}`}
                          className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm cursor-grab active:cursor-grabbing hover:border-indigo-100 transition-colors"
                        >
                          <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-4 sticky top-0 bg-white z-10 pt-2">
                            <h2 className="text-2xl font-bold text-slate-800">
                              {selectedLanguage === 'en' ? ch.title : (ch.translations?.[selectedLanguage]?.title || ch.title)}
                            </h2>
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1.5 text-slate-400">
                                <FileText className="w-4 h-4" />
                                <span className="text-xs font-bold">{chapterWordCounts[ch.id!] || 0} words</span>
                              </div>
                              {ch.isReviewed && (
                                <div className="flex items-center gap-1.5 px-2 py-1 bg-green-50 text-green-600 rounded-lg border border-green-100">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span className="text-[10px] font-bold uppercase tracking-wider">Reviewed</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <ChapterContent 
                            chapter={ch} 
                            projectId={currentProject.id!} 
                            niche={currentProject.niche}
                            tone={currentProject.tone}
                            setError={setError} 
                            onWordCountUpdate={(count) => setChapterWordCounts(prev => ({ ...prev, [ch.id!]: count }))}
                            onToggleReview={toggleChapterReview}
                            selectedLanguage={selectedLanguage}
                          />
                        </Reorder.Item>
                      ))}
                    </Reorder.Group>

                    <div className="flex justify-end gap-4 pt-8 border-t border-slate-200">
                      <Button onClick={() => setStep('outline')} className="bg-slate-100 text-slate-700">
                        Edit Outline
                      </Button>
                      <Button onClick={() => setStep('upload')} className="bg-slate-100 text-slate-700">
                        Regenerate
                      </Button>
                      <Button onClick={() => setStep('cover')} className="bg-indigo-600 text-white px-8">
                        Next: Generate Cover
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
                  <Sparkles className="w-12 h-12 text-indigo-200 mx-auto mb-4" />
                  <h3 className="text-lg font-medium">Ready to Forge?</h3>
                  <p className="text-slate-500 mb-6 max-w-md mx-auto">Our AI will structure your content into professional chapters with hooks, takeaways, and action steps.</p>
                  <Button onClick={startGeneration} className="bg-indigo-600 text-white mx-auto">
                    Launch AI Engine
                  </Button>
                </div>
              )}
            </motion.div>
          )}

          {step === 'cover' && (
            <motion.div 
              key="cover"
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="text-center space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Cover Art Generator</h2>
                <p className="text-slate-500">Creating a brand-aligned cover for "{currentProject?.title}"</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                <div className="space-y-6">
                  <Card className="p-6 space-y-4">
                    <h3 className="font-bold text-lg">Customize Style</h3>
                    <div className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Style Preferences (Select Multiple)</label>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => setCoverStyles(COVER_STYLES.map(s => s.id))}
                              className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700 transition-colors uppercase tracking-tight"
                            >
                              Select All
                            </button>
                            <span className="text-slate-300 text-[10px]">|</span>
                            <button 
                              onClick={() => setCoverStyles([])}
                              className="text-[10px] font-bold text-slate-400 hover:text-slate-500 transition-colors uppercase tracking-tight"
                            >
                              Clear
                            </button>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {COVER_STYLES.map((style) => {
                            const isActive = coverStyles.includes(style.id);
                            return (
                              <button
                                key={style.id}
                                onClick={() => {
                                  if (isActive) {
                                    setCoverStyles(coverStyles.filter(s => s !== style.id));
                                  } else {
                                    setCoverStyles([...coverStyles, style.id]);
                                  }
                                }}
                                className={cn(
                                  "relative text-left p-3 rounded-xl text-xs font-bold transition-all border-2",
                                  isActive 
                                    ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100 scale-[1.02]" 
                                    : "bg-white border-slate-100 text-slate-600 hover:border-indigo-100 hover:bg-slate-50"
                                )}
                              >
                                {style.label}
                                {isActive && (
                                  <motion.div 
                                    layoutId="active-style"
                                    className="absolute top-1 right-1"
                                  >
                                    <Check className="w-3 h-3 text-white" />
                                  </motion.div>
                                )}
                              </button>
                            );
                          })}
                        </div>
                        <p className="text-[10px] text-slate-400 italic">
                          {coverStyles.length === 0 
                            ? "Select at least one style to generate variations." 
                            : `${coverStyles.length} style${coverStyles.length > 1 ? 's' : ''} selected. We'll generate a variation for each.`}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Keywords (Optional)</label>
                        <textarea 
                          value={coverKeywords}
                          onChange={(e) => setCoverKeywords(e.target.value)}
                          placeholder="e.g. mountain landscape, blue and gold, geometric patterns..."
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none h-24 resize-none"
                        />
                      </div>
                      <Button 
                        onClick={generateCover} 
                        disabled={isGenerating || !coverStyles.length}
                        className="w-full bg-indigo-600 text-white shadow-md"
                      >
                        {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                        {currentProject?.coverUrls?.length ? "Regenerate Variations" : "Generate Cover Variations"}
                      </Button>

                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-slate-200" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-white px-2 text-slate-400 font-bold">Or Upload Your Own</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-center w-full">
                        <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 border-dashed rounded-xl cursor-pointer bg-slate-50 hover:bg-slate-100 transition-all hover:border-indigo-300 group">
                          <div className="flex flex-col items-center justify-center pt-5 pb-6">
                            <Upload className="w-8 h-8 mb-3 text-slate-400 group-hover:text-indigo-500 transition-colors" />
                            <p className="mb-2 text-sm text-slate-500"><span className="font-bold">Click to upload</span> or drag and drop</p>
                            <p className="text-xs text-slate-400">PNG, JPG or JPEG (Recommended 3:4 ratio)</p>
                          </div>
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*"
                            onChange={handleCoverUpload}
                            disabled={isGenerating}
                          />
                        </label>
                      </div>
                    </div>
                  </Card>

                  {currentProject?.coverUrl && (
                    <div className="flex justify-center">
                      <Button onClick={() => setStep('publish')} className="bg-slate-900 text-white px-8">
                        Next: Publishing
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h4 className="font-bold text-sm uppercase tracking-widest text-slate-400 text-center">Preview Variations</h4>
                  <div className="grid grid-cols-1 gap-6">
                    <AnimatePresence mode="wait">
                      {isGenerating ? (
                        <motion.div 
                          key="loading"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="aspect-[3/4] max-w-sm mx-auto w-full bg-slate-100 rounded-2xl flex flex-col items-center justify-center space-y-4 border-2 border-dashed border-slate-200 shadow-inner z-10"
                        >
                          <div className="relative">
                            <div className="w-16 h-16 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                            <Sparkles className="w-6 h-6 text-amber-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                          </div>
                          <div className="text-center">
                            <p className="text-slate-900 font-bold">Generating Art</p>
                            <p className="text-slate-500 text-xs px-4">{generationProgress}</p>
                          </div>
                        </motion.div>
                      ) : currentProject?.coverUrls?.length ? (
                        <div className="grid grid-cols-2 gap-4">
                          {currentProject.coverUrls.map((url, idx) => (
                            <motion.div 
                              key={idx}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className={cn(
                                "relative aspect-[3/4] bg-white rounded-xl shadow-lg overflow-hidden border transition-all cursor-pointer group",
                                currentProject.coverUrl === url ? "border-indigo-500 ring-4 ring-indigo-50" : "border-slate-200"
                              )}
                              onClick={() => {
                                setCurrentProject(prev => prev ? { ...prev, coverUrl: url } : null);
                                updateDoc(doc(db, 'projects', currentProject.id!), { coverUrl: url });
                              }}
                            >
                              <img src={url} alt={`Variation ${idx + 1}`} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <Check className={cn(
                                  "w-8 h-8 text-white transition-transform",
                                  currentProject.coverUrl === url ? "scale-100" : "scale-0"
                                )} />
                              </div>
                              {currentProject.coverUrl === url && (
                                <div className="absolute top-2 right-2 bg-indigo-600 text-white p-1 rounded-full shadow-lg">
                                  <Check className="w-3 h-3" />
                                </div>
                              )}
                            </motion.div>
                          ))}
                        </div>
                      ) : currentProject?.coverUrl ? (
                         <motion.div 
                          key="preview"
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="aspect-[3/4] max-w-sm mx-auto w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 group"
                        >
                          <img src={currentProject.coverUrl} alt="Ebook Cover" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                        </motion.div>
                      ) : (
                        <motion.div 
                          key="placeholder"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="aspect-[3/4] max-w-sm mx-auto w-full bg-white rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center p-8 text-center space-y-6 shadow-inner"
                        >
                          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center">
                            <ImageIcon className="w-10 h-10 text-slate-200" />
                          </div>
                          <div>
                            <h3 className="font-bold text-lg text-slate-400">Ready to Design</h3>
                            <p className="text-sm text-slate-400">Select multiple styles to see the magic happen.</p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'publish' && (
            <motion.div 
              key="publish"
              className="max-w-3xl mx-auto space-y-8"
            >
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tight">Publishing Dashboard</h2>
                <p className="text-slate-500">Configure your metadata and select target marketplaces.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h4 className="font-bold text-sm uppercase tracking-widest text-slate-400">Metadata</h4>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">Title</label>
                      <input 
                        type="text" 
                        value={currentProject?.title || ""}
                        onChange={(e) => setCurrentProject(prev => prev ? { ...prev, title: e.target.value } : null)}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">Author Name</label>
                      <input 
                        type="text" 
                        value={currentProject?.author || ""}
                        onChange={(e) => setCurrentProject(prev => prev ? { ...prev, author: e.target.value } : null)}
                        placeholder="Your Name"
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">Pricing (USD)</label>
                      <div className="relative">
                         <span className="absolute left-3 top-2 text-slate-400">$</span>
                         <input 
                           type="number" 
                           value={currentProject?.pricing || 9.99}
                           onChange={(e) => setCurrentProject(prev => prev ? { ...prev, pricing: parseFloat(e.target.value) } : null)}
                           step="0.01"
                           className="w-full p-2 pl-7 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                         />
                      </div>
                    </div>

                    <div className="pt-2">
                      <label className="flex items-center justify-between p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl cursor-pointer hover:bg-indigo-50 transition-all">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm">
                            <ShieldCheck className="w-4 h-4 text-indigo-600" />
                          </div>
                          <div>
                            <span className="text-sm font-bold text-slate-900">AI Fact-Checking</span>
                            <p className="text-[10px] text-slate-500">Automatically verify claims during generation</p>
                          </div>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={currentProject?.autoFactCheck ?? true} 
                          onChange={(e) => setCurrentProject(prev => prev ? { ...prev, autoFactCheck: e.target.checked } : null)}
                          className="w-5 h-5 accent-indigo-600" 
                        />
                      </label>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-slate-100">
                      <h4 className="font-bold text-sm uppercase tracking-widest text-slate-400">Formatting</h4>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Font Family</label>
                        <select 
                          value={fontFamily}
                          onChange={(e) => setFontFamily(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        >
                          <option value="Inter">Inter (Sans-serif)</option>
                          <option value="Merriweather">Merriweather (Serif)</option>
                          <option value="JetBrains Mono">JetBrains Mono (Monospace)</option>
                          <option value="Playfair Display">Playfair Display (Elegant)</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Font Size ({fontSize}px)</label>
                        <input 
                          type="range" 
                          min="12" 
                          max="24" 
                          step="1" 
                          value={fontSize}
                          onChange={(e) => setFontSize(parseInt(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-full appearance-none cursor-pointer accent-indigo-600"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Text Alignment</label>
                        <div className="flex gap-2">
                          {[
                            { id: 'left', icon: AlignLeft },
                            { id: 'center', icon: AlignCenter },
                            { id: 'justify', icon: AlignJustify }
                          ].map((align) => (
                            <button
                              key={align.id}
                              onClick={() => setTextAlign(align.id as any)}
                              className={cn(
                                "flex-1 p-2 rounded-lg border transition-all flex justify-center",
                                textAlign === align.id 
                                  ? "bg-indigo-50 border-indigo-200 text-indigo-600" 
                                  : "bg-white border-slate-200 text-slate-400 hover:border-slate-300"
                              )}
                            >
                              <align.icon className="w-4 h-4" />
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">Line Spacing ({lineSpacing})</label>
                        <input 
                          type="range" 
                          min="1" 
                          max="2.5" 
                          step="0.1" 
                          value={lineSpacing}
                          onChange={(e) => setLineSpacing(parseFloat(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <h4 className="font-bold text-sm uppercase tracking-widest text-slate-400">Marketplaces</h4>
                  <div className="space-y-3">
                    {[
                      { id: 'amazon', label: 'Amazon KDP' },
                      { id: 'apple', label: 'Apple Books' },
                      { id: 'google', label: 'Google Play Books' }
                    ].map((m) => (
                      <label key={m.id} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-indigo-600 transition-all">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                            <Send className="w-5 h-5 text-slate-400" />
                          </div>
                          <span className="font-bold">{m.label}</span>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={currentProject?.platforms?.[m.id as keyof typeof currentProject.platforms] ?? true} 
                          onChange={(e) => {
                            const newPlatforms = { ...(currentProject?.platforms || { amazon: true, apple: true, google: true }), [m.id]: e.target.checked };
                            setCurrentProject(prev => prev ? { ...prev, platforms: newPlatforms } : null);
                          }}
                          className="w-5 h-5 accent-indigo-600" 
                        />
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-200 flex justify-end gap-4">
                <Button onClick={() => setStep('cover')} className="bg-slate-100 text-slate-700">
                  Back
                </Button>
                <Button 
                  onClick={() => {
                    const platforms = Object.entries(currentProject?.platforms || { amazon: true, apple: true, google: true })
                      .filter(([_, checked]) => checked)
                      .map(([id]) => id);
                    publishEbook(platforms, currentProject?.pricing || 9.99, { fontFamily, lineSpacing, fontSize, textAlign });
                  }}
                  disabled={isGenerating}
                  className="bg-indigo-600 text-white px-8 py-4 text-lg shadow-lg"
                >
                  {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  Publish to Marketplaces
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'done' && (
            <motion.div 
              key="done"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto text-center space-y-8"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <div className="space-y-2">
                <h2 className="text-4xl font-bold tracking-tight">Publishing Complete!</h2>
                <p className="text-slate-500 text-lg">Your ebook "{currentProject?.title}" has been submitted to the selected marketplaces.</p>
              </div>

              <div className="bg-white p-8 rounded-2xl border border-slate-200 space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <FileText className="w-6 h-6 text-indigo-600" />
                    <div className="text-left">
                      <p className="font-bold text-sm">{currentProject?.title}</p>
                      <p className="text-xs text-slate-400">Manage export formats</p>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setShowExportModal(true)}
                    disabled={isExporting}
                    className="bg-indigo-600 text-white px-4 py-2 flex items-center gap-2"
                  >
                    {isExporting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Exporting...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>Export Manager</span>
                      </>
                    )}
                  </Button>
                </div>

                {isExporting && (
                  <div className="px-4 pb-4">
                    <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ x: "-100%" }}
                        animate={{ x: "100%" }}
                        transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                        className="h-full w-1/3 bg-indigo-600"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest text-left">Marketplace Listings</h3>
                  <div className="grid grid-cols-1 gap-3">
                    {[
                      { id: 'amazon', name: 'Amazon Kindle', icon: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg' },
                      { id: 'apple', name: 'Apple Books', icon: 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg' },
                      { id: 'google', name: 'Google Play Books', icon: 'https://upload.wikimedia.org/wikipedia/commons/d/d0/Google_Play_Arrow_logo.svg' },
                      { id: 'other', name: 'Other Marketplace', icon: null }
                    ].map(p => (
                      <div key={p.id} className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 transition-all hover:border-indigo-100">
                        <div className="flex items-center gap-3 flex-1 w-full">
                          <div className="w-8 h-8 flex items-center justify-center bg-white rounded-lg shadow-sm border border-slate-100 shrink-0">
                            {p.icon ? (
                              <img src={p.icon} alt={p.name} className="w-5 h-5 object-contain" referrerPolicy="no-referrer" />
                            ) : (
                              <ExternalLink className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                          <div className="text-left flex-1 min-w-0">
                            <p className="text-xs font-bold text-slate-900 truncate">{p.name}</p>
                            {currentProject?.marketplaceLinks?.[p.id as keyof typeof currentProject.marketplaceLinks] ? (
                              <a 
                                href={currentProject.marketplaceLinks[p.id as keyof typeof currentProject.marketplaceLinks]} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-[10px] text-indigo-600 hover:underline flex items-center gap-1 truncate"
                              >
                                View Listing <ExternalLink className="w-2 h-2" />
                              </a>
                            ) : (
                              <p className="text-[10px] text-slate-400 italic">No link added yet</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <input 
                            type="url"
                            placeholder="Paste listing URL..."
                            value={marketplaceUrls[p.id as keyof typeof marketplaceUrls]}
                            onChange={(e) => setMarketplaceUrls(prev => ({ ...prev, [p.id]: e.target.value }))}
                            className="flex-1 sm:w-48 text-xs p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                          />
                          <Button 
                            onClick={() => updateMarketplaceLink(p.id, marketplaceUrls[p.id as keyof typeof marketplaceUrls])}
                            disabled={!marketplaceUrls[p.id as keyof typeof marketplaceUrls]}
                            className="bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-200 p-2 shadow-sm"
                          >
                            <Save className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Button onClick={() => setStep('list')} className="bg-slate-900 text-white px-8 mx-auto">
                Return to Dashboard
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      ) : (
        <AccessDeniedView
          featureName="Creator Studio & Publishing Pipeline"
          onGoToStorefront={() => setCurrentView('storefront')}
        />
      )
      )}

      {/* Global Commerce Checkout Drawer */}
      <CommerceCheckout
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onRemoveFromCart={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onCompleteOrder={handleCompleteOrder}
        onNavigateToLibrary={() => { setCurrentView('library'); setIsCartOpen(false); }}
      />


      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 py-12 border-t border-slate-200 mt-20">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-slate-400" />
            <span className="font-bold text-slate-400">EbookForge &copy; 2026</span>
          </div>
          <div className="flex gap-8 text-sm text-slate-400 font-medium">
            <a href="#" className="hover:text-indigo-600">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-600">Terms of Service</a>
            <a href="#" className="hover:text-indigo-600">Help Center</a>
          </div>
        </div>
      </footer>

      {showPreview && currentProject && (
        <PreviewMode 
          project={currentProject} 
          chapters={currentChapters} 
          onClose={() => setShowPreview(false)} 
          selectedLanguage={selectedLanguage}
        />
      )}

      {showProjectDetails && currentProject && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="project-details-title"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border dark:border-slate-800"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 id="project-details-title" className="text-xl font-bold dark:text-white">Project Details</h3>
              <Button 
                onClick={() => setShowProjectDetails(false)} 
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"
                aria-label="Close Project Details"
              >
                <X className="w-5 h-5 text-slate-400" />
              </Button>
            </div>
            <div className="p-8 space-y-6 max-h-[80vh] overflow-y-auto">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Ebook Title</label>
                  <input 
                    type="text"
                    value={currentProject.title}
                    onChange={async (e) => {
                      const newTitle = e.target.value;
                      setCurrentProject(prev => prev ? { ...prev, title: newTitle } : null);
                      try {
                        await updateDoc(doc(db, 'projects', currentProject.id!), { title: newTitle, updatedAt: serverTimestamp() });
                      } catch (err) {
                        handleFirestoreError(err, OperationType.UPDATE, `projects/${currentProject.id}`);
                      }
                    }}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Author Name</label>
                  <input 
                    type="text"
                    value={currentProject.author || ''}
                    placeholder="Enter author name..."
                    onChange={async (e) => {
                      const newAuthor = e.target.value;
                      setCurrentProject(prev => prev ? { ...prev, author: newAuthor } : null);
                      try {
                        await updateDoc(doc(db, 'projects', currentProject.id!), { author: newAuthor, updatedAt: serverTimestamp() });
                      } catch (err) {
                        handleFirestoreError(err, OperationType.UPDATE, `projects/${currentProject.id}`);
                      }
                    }}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Marketplace Listings</label>
                <div className="space-y-3">
                  {[
                    { id: 'amazon', name: 'Amazon Kindle', icon: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg' },
                    { id: 'apple', name: 'Apple Books', icon: 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg' },
                    { id: 'google', name: 'Google Play Books', icon: 'https://upload.wikimedia.org/wikipedia/commons/d/d0/Google_Play_Arrow_logo.svg' },
                    { id: 'other', name: 'Other Marketplace', icon: null }
                  ].map(p => (
                    <div key={p.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                      <div className="w-8 h-8 flex items-center justify-center bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 shrink-0">
                        {p.icon ? (
                          <img src={p.icon} alt={p.name} className="w-5 h-5 object-contain" referrerPolicy="no-referrer" />
                        ) : (
                          <ExternalLink className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <input 
                          type="url"
                          placeholder={`Paste ${p.name} URL...`}
                          value={marketplaceUrls[p.id as keyof typeof marketplaceUrls]}
                          onChange={(e) => setMarketplaceUrls(prev => ({ ...prev, [p.id]: e.target.value }))}
                          onBlur={() => updateMarketplaceLink(p.id, marketplaceUrls[p.id as keyof typeof marketplaceUrls])}
                          className="w-full text-xs p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <Button 
                  onClick={() => setShowProjectDetails(false)}
                  className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-3"
                >
                  Close
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {showSettings && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="settings-title"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border dark:border-slate-800"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 id="settings-title" className="text-xl font-bold dark:text-white">User Settings</h3>
              <Button 
                onClick={() => setShowSettings(false)} 
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"
                aria-label="Close Settings"
              >
                <X className="w-5 h-5 text-slate-400" />
              </Button>
            </div>
            <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
              {/* Logo Section */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Custom Application Logo</label>
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-dashed border-slate-200 dark:border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                    {userLogoUrl ? (
                      <img src={userLogoUrl} alt="Custom Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                    ) : (
                      <ImageIcon className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                    )}
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="file" 
                      id="logo-upload" 
                      className="hidden" 
                      accept="image/*"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file && user) {
                          const loadingToast = toast.loading("Uploading logo...");
                          try {
                            const storageRef = ref(storage, `users/${user.uid}/logo`);
                            await uploadBytes(storageRef, file);
                            const url = await getDownloadURL(storageRef);
                            await updateUserSettings({ 
                              theme: appTheme,
                              uiFont: appFont,
                              customLogoUrl: url 
                            });
                            toast.dismiss(loadingToast);
                            toast.success("Logo updated successfully!");
                          } catch (err) {
                            toast.dismiss(loadingToast);
                            toast.error("Failed to upload logo");
                          }
                        }
                      }}
                    />
                    <Button 
                      onClick={() => document.getElementById('logo-upload')?.click()}
                      className="bg-indigo-600 text-white text-sm py-2 px-4"
                    >
                      <Upload className="w-4 h-4" />
                      Upload Logo
                    </Button>
                    {userLogoUrl && (
                      <Button 
                        onClick={async () => {
                          await updateUserSettings({ 
                            theme: appTheme,
                            uiFont: appFont,
                            customLogoUrl: null 
                          });
                          toast.success("Logo reset to default.");
                        }}
                        className="text-red-500 text-xs hover:underline block"
                      >
                        Reset to Default
                      </Button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">This logo will replace the default EbookForge branding in the header.</p>
              </div>

              {/* Appearance Section */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Appearance</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    onClick={() => {
                      setAppTheme('light');
                      updateUserSettings({ theme: 'light', uiFont: appFont, customLogoUrl: userLogoUrl });
                    }}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all",
                      appTheme === 'light' 
                        ? "bg-indigo-50 border-indigo-600 text-indigo-600 shadow-sm" 
                        : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400 hover:border-slate-200 dark:hover:border-slate-600"
                    )}
                  >
                    <Sun className="w-5 h-5 mb-1" />
                    <span className="font-bold text-sm">Light</span>
                  </button>
                  <button
                    onClick={() => {
                      setAppTheme('dark');
                      updateUserSettings({ theme: 'dark', uiFont: appFont, customLogoUrl: userLogoUrl });
                    }}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all",
                      appTheme === 'dark' 
                        ? "bg-indigo-900/20 border-indigo-500 text-indigo-400 shadow-sm" 
                        : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400 hover:border-slate-200 dark:hover:border-slate-600"
                    )}
                  >
                    <Moon className="w-5 h-5 mb-1" />
                    <span className="font-bold text-sm">Dark</span>
                  </button>
                  <button
                    onClick={() => {
                      setAppTheme('high-contrast');
                      updateUserSettings({ theme: 'high-contrast', uiFont: appFont, customLogoUrl: userLogoUrl });
                    }}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all",
                      appTheme === 'high-contrast' 
                        ? "bg-black border-yellow-400 text-yellow-400 shadow-sm" 
                        : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400 hover:border-slate-200 dark:hover:border-slate-600"
                    )}
                  >
                    <Eye className="w-5 h-5 mb-1" />
                    <span className="font-bold text-sm">Contrast</span>
                  </button>
                </div>
              </div>

              {/* UI Font Section */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">UI Typography</label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { name: 'Inter', label: 'Inter (Modern Sans)' },
                    { name: 'Outfit', label: 'Outfit (Geometric)' },
                    { name: 'Space Grotesk', label: 'Space Grotesk (Tech)' },
                    { name: 'Playfair Display', label: 'Playfair Display (Serif)' }
                  ].map((font) => (
                    <button
                      key={font.name}
                      onClick={() => {
                        setAppFont(font.name);
                        updateUserSettings({ theme: appTheme, uiFont: font.name, customLogoUrl: userLogoUrl });
                      }}
                      className={cn(
                        "w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between",
                        appFont === font.name 
                          ? "bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400" 
                          : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-200 dark:hover:border-slate-600"
                      )}
                      style={{ fontFamily: font.name }}
                    >
                      <span className="font-medium">{font.label}</span>
                      {appFont === font.name && <CheckCircle2 className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <Button 
                  onClick={() => setShowSettings(false)}
                  className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-3"
                >
                  Done
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {showExportModal && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="export-title"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 dark:bg-indigo-900/40 rounded-xl">
                  <Download className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div>
                  <h3 id="export-title" className="text-xl font-bold dark:text-white">Export Ebook</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Choose format and quality</p>
                </div>
              </div>
              <button 
                onClick={() => setShowExportModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="space-y-3">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">File Format</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: 'epub', name: 'EPUB', desc: 'Best for Kindle & readers' },
                    { id: 'pdf', name: 'PDF', desc: 'Preserves formatting' },
                    { id: 'zip', name: 'ZIP', desc: 'Raw Markdown (.md)' }
                  ].map(f => (
                    <div 
                      key={f.id}
                      onClick={() => setExportFormat(f.id as any)}
                      className={cn(
                        "p-3 rounded-xl border-2 cursor-pointer transition-all",
                        exportFormat === f.id 
                          ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20" 
                          : "border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700"
                      )}
                    >
                      <h4 className={cn("font-bold", exportFormat === f.id ? "text-indigo-700 dark:text-indigo-400" : "text-slate-700 dark:text-slate-300")}>{f.name}</h4>
                      <p className="text-[10px] text-slate-500 dark:text-slate-500 mt-1">{f.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {exportFormat === 'pdf' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Page Size</label>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="pageSize" 
                          value="a4" 
                          checked={exportPageSize === 'a4'}
                          onChange={() => setExportPageSize('a4')}
                          className="text-indigo-600"
                        />
                        <span className="text-sm dark:text-slate-300">A4 Document</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="pageSize" 
                          value="letter" 
                          checked={exportPageSize === 'letter'}
                          onChange={() => setExportPageSize('letter')}
                          className="text-indigo-600"
                        />
                        <span className="text-sm dark:text-slate-300">US Letter</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {exportFormat !== 'zip' && (
                <div className="space-y-3 pt-2">
                  <label className="flex items-center gap-3 cursor-pointer p-3 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <div className={cn(
                      "w-5 h-5 rounded flex items-center justify-center border",
                      exportIncludeCover ? "bg-indigo-600 border-indigo-600" : "border-slate-300 dark:border-slate-600"
                    )}>
                      {exportIncludeCover && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                    </div>
                    <div>
                      <span className="text-sm font-bold text-slate-700 dark:text-slate-300 block">Include Cover Image</span>
                      <span className="text-[10px] text-slate-500 block">Insert the generated cover art as the first page.</span>
                    </div>
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={exportIncludeCover} 
                      onChange={(e) => setExportIncludeCover(e.target.checked)} 
                    />
                  </label>
                </div>
              )}
            </div>
            
            <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-end gap-3">
              <Button 
                onClick={() => setShowExportModal(false)}
                className="bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={executeExport}
                disabled={isExporting}
                className="bg-indigo-600 text-white min-w-[120px]"
              >
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                Export {exportFormat.toUpperCase()}
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {showTranslationModal && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="translation-title"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
          >
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 id="translation-title" className="text-xl font-bold">Translate Ebook</h3>
              <Button 
                onClick={() => setShowTranslationModal(false)} 
                className="p-2 hover:bg-slate-100 rounded-full"
                aria-label="Close Translation Modal"
              >
                <X className="w-5 h-5 text-slate-400" />
              </Button>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Select Target Language</label>
                <div className="grid grid-cols-2 gap-2">
                  {LANGUAGES.filter(l => l.code !== 'en').map(lang => (
                    <button
                      key={lang.code}
                      onClick={() => translateEbook(lang.code)}
                      className="p-3 rounded-xl border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50 transition-all text-left group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-700 group-hover:text-indigo-600">{lang.name}</span>
                        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-400" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <p className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <Sparkles className="w-3 h-3 inline mr-1 text-indigo-500" />
                AI will translate all chapters while preserving your formatting and tone. This may take a few moments per chapter.
              </p>
            </div>
          </motion.div>
        </div>
      )}

      {projectToDelete && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="delete-title"
          aria-describedby="delete-description"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden border dark:border-slate-800"
          >
            <div className="p-6 text-center space-y-4">
              <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto">
                <Trash2 className="w-8 h-8 text-red-600 dark:text-red-400" aria-hidden="true" />
              </div>
              <h3 id="delete-title" className="text-xl font-bold dark:text-white">Delete Project?</h3>
              <p id="delete-description" className="text-sm text-slate-500 dark:text-slate-400">
                Are you sure you want to delete <strong>"{projectToDelete.title}"</strong>? This action cannot be undone and all associated content will be permanently lost.
              </p>
            </div>
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 flex gap-3">
              <Button 
                onClick={() => setProjectToDelete(null)}
                className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  deleteProject(projectToDelete.id!);
                  setProjectToDelete(null);
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white"
              >
                Delete
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {showCustomTemplateModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full flex flex-col max-h-[90vh] overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 className="text-xl font-bold dark:text-white">Create Custom Template</h3>
              <Button 
                onClick={() => setShowCustomTemplateModal(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"
              >
                <X className="w-5 h-5 text-slate-400" />
              </Button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Template Name</label>
                  <input
                    type="text"
                    value={newTemplateData.name}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Action Thriller Novel"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Description</label>
                  <textarea
                    value={newTemplateData.description}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 h-24 resize-none"
                    placeholder="Brief description of when to use this template..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Writing Style</label>
                  <input
                    type="text"
                    value={newTemplateData.defaultWritingStyle}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, defaultWritingStyle: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Fast-paced, concise, descriptive"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Tone</label>
                    <input
                      type="text"
                      value={newTemplateData.defaultTone}
                      onChange={e => setNewTemplateData(prev => ({ ...prev, defaultTone: e.target.value }))}
                      className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Dramatic"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Audience</label>
                    <input
                      type="text"
                      value={newTemplateData.defaultAudience}
                      onChange={e => setNewTemplateData(prev => ({ ...prev, defaultAudience: e.target.value }))}
                      className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Young Adult"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3 bg-slate-50 dark:bg-slate-900/50">
              <Button 
                onClick={() => setShowCustomTemplateModal(false)}
                className="px-6 py-2 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (!newTemplateData.name) {
                    toast.error("Please enter a template name");
                    return;
                  }
                  const newTemplate: ProjectTemplate = {
                    id: `custom-${Date.now()}`,
                    name: newTemplateData.name || 'Custom Template',
                    description: newTemplateData.description || 'A custom project template.',
                    icon: 'BookOpen',
                    defaultWritingStyle: newTemplateData.defaultWritingStyle || 'Clear and concise',
                    defaultTone: newTemplateData.defaultTone || 'Professional',
                    defaultAudience: newTemplateData.defaultAudience || 'General',
                    defaultFormatting: {
                      fontFamily: appFont,
                      lineSpacing: 1.6,
                      fontSize: 16,
                      textAlign: 'left'
                    },
                    suggestedNiches: []
                  };
                  setCustomTemplates(prev => [...prev, newTemplate]);
                  setShowCustomTemplateModal(false);
                  setNewTemplateData({
                    name: '',
                    description: '',
                    defaultWritingStyle: '',
                    defaultTone: 'Professional',
                    defaultAudience: 'General',
                  });
                  toast.success("Custom template created successfully!");
                }}
                className="px-6 py-2 bg-indigo-600 text-white shadow-sm"
              >
                Save Template
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {showCustomTemplateModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full flex flex-col max-h-[90vh] overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 className="text-xl font-bold dark:text-white">Create Custom Template</h3>
              <Button 
                onClick={() => setShowCustomTemplateModal(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full"
              >
                <X className="w-5 h-5 text-slate-400" />
              </Button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Template Name</label>
                  <input
                    type="text"
                    value={newTemplateData.name}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Action Thriller Novel"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Description</label>
                  <textarea
                    value={newTemplateData.description}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 h-24 resize-none"
                    placeholder="Brief description of when to use this template..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Writing Style</label>
                  <input
                    type="text"
                    value={newTemplateData.defaultWritingStyle}
                    onChange={e => setNewTemplateData(prev => ({ ...prev, defaultWritingStyle: e.target.value }))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Fast-paced, concise, descriptive"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Tone</label>
                    <input
                      type="text"
                      value={newTemplateData.defaultTone}
                      onChange={e => setNewTemplateData(prev => ({ ...prev, defaultTone: e.target.value }))}
                      className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Dramatic"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">Default Audience</label>
                    <input
                      type="text"
                      value={newTemplateData.defaultAudience}
                      onChange={e => setNewTemplateData(prev => ({ ...prev, defaultAudience: e.target.value }))}
                      className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                      placeholder="e.g. Young Adult"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3 bg-slate-50 dark:bg-slate-900/50">
              <Button 
                onClick={() => setShowCustomTemplateModal(false)}
                className="px-6 py-2 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (!newTemplateData.name) {
                    toast.error("Please enter a template name");
                    return;
                  }
                  const newTemplate: ProjectTemplate = {
                    id: `custom-${Date.now()}`,
                    name: newTemplateData.name || 'Custom Template',
                    description: newTemplateData.description || 'A custom project template.',
                    icon: 'BookOpen',
                    defaultWritingStyle: newTemplateData.defaultWritingStyle || 'Clear and concise',
                    defaultTone: newTemplateData.defaultTone || 'Professional',
                    defaultAudience: newTemplateData.defaultAudience || 'General',
                    defaultFormatting: {
                      fontFamily: appFont,
                      lineSpacing: 1.6,
                      fontSize: 16,
                      textAlign: 'left'
                    },
                    suggestedNiches: []
                  };
                  setCustomTemplates(prev => [...prev, newTemplate]);
                  setShowCustomTemplateModal(false);
                  setNewTemplateData({
                    name: '',
                    description: '',
                    defaultWritingStyle: '',
                    defaultTone: 'Professional',
                    defaultAudience: 'General',
                  });
                  toast.success("Custom template created successfully!");
                }}
                className="px-6 py-2 bg-indigo-600 text-white shadow-sm"
              >
                Save Template
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      <Toaster position="bottom-right" richColors />
      <CollaboratorsModal 
        isOpen={showCollaboratorsModal}
        onClose={() => setShowCollaboratorsModal(false)}
        project={currentProject!}
        onInvite={inviteCollaborator}
        onRemove={removeCollaborator}
      />
    </div>
  );
}
