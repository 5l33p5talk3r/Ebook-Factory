-- Migration: 0001_init.sql
-- Cloudflare D1 Initial Database Schema for EbookFactory

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  display_name TEXT,
  role TEXT DEFAULT 'user',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  author TEXT,
  niche TEXT NOT NULL,
  cover_url TEXT,
  status TEXT DEFAULT 'draft',
  pricing REAL DEFAULT 9.99,
  outline_json TEXT,
  formatting_json TEXT,
  marketplace_links_json TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  project_id TEXT,
  title TEXT NOT NULL,
  subtitle TEXT,
  author TEXT NOT NULL,
  niche TEXT NOT NULL,
  category TEXT NOT NULL,
  price REAL NOT NULL,
  cover_url TEXT,
  description TEXT,
  rating REAL DEFAULT 5.0,
  sales_count INTEGER DEFAULT 0,
  sample_chapter TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  customer_email TEXT NOT NULL,
  total_amount REAL NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'COMPLETED',
  paypal_order_id TEXT,
  receipt_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS download_entitlements (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL,
  user_id TEXT,
  product_id TEXT NOT NULL,
  title TEXT NOT NULL,
  download_url TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE TABLE IF NOT EXISTS niche_researches (
  id TEXT PRIMARY KEY,
  topic TEXT NOT NULL,
  opportunity_score INTEGER NOT NULL,
  demand_level TEXT NOT NULL,
  competition_level TEXT NOT NULL,
  profit_potential TEXT NOT NULL,
  report_json TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_entitlements_user ON download_entitlements(user_id);
