# Cloudflare Deployment Guide — EbookFactory

This guide provides step-by-step instructions for deploying **EbookFactory** to **Cloudflare Workers / Cloudflare Pages** with **Cloudflare D1 SQL Database** and **PayPal Integration**.

---

## 1. Prerequisites

- [Node.js](https://nodejs.org/) v18+ and `npm` installed.
- A Cloudflare account and [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/get-started-with-wrangler/):
  ```bash
  npm install -g wrangler
  wrangler login
  ```

---

## 2. Cloudflare D1 Database Setup

1. Create a new D1 database:
   ```bash
   wrangler d1 create ebook-factory-db
   ```
2. Copy the `database_id` returned by the CLI and update your `wrangler.toml`:
   ```toml
   [[d1_databases]]
   binding = "DB"
   database_name = "ebook-factory-db"
   database_id = "YOUR_ACTUAL_D1_DATABASE_ID_HERE"
   ```

3. Execute the SQL schema migration against Cloudflare D1:
   - For local development database:
     ```bash
     wrangler d1 execute ebook-factory-db --local --file=./migrations/0001_init.sql
     ```
   - For remote production database:
     ```bash
     wrangler d1 execute ebook-factory-db --remote --file=./migrations/0001_init.sql
     ```

---

## 3. Environment Variables & Secrets Configuration

Set production secrets securely on Cloudflare Workers using `wrangler secret`:

1. **Gemini API Key**:
   ```bash
   wrangler secret put GEMINI_API_KEY
   ```
2. **PayPal Client ID**:
   ```bash
   wrangler secret put PAYPAL_CLIENT_ID
   ```
3. **PayPal Client Secret**:
   ```bash
   wrangler secret put PAYPAL_CLIENT_SECRET
   ```

*(For local development, copy `.env.example` to `.env` and fill in your keys.)*

---

## 4. Build and Deployment

1. Build the frontend SPA distribution artifacts:
   ```bash
   npm run build
   ```

2. Deploy worker and static site to Cloudflare:
   ```bash
   wrangler deploy
   ```

---

## 5. Verification & Testing

- Access your deployed Cloudflare URL (e.g. `https://ebook-factory.your-subdomain.workers.dev`).
- Verify Storefront, Niche Intelligence AI research, Ebook Generator, and Checkout flow.
- If PayPal credentials are not configured or set to sandbox mode, checkout automatically falls back to an instant test environment so orders complete cleanly.

---

## 6. Architecture Highlights

- **Edge Worker Handler (`worker.ts`)**: Built with standard Web APIs (`fetch`, `Request`, `Response`) for instant cold starts and sub-50ms latency globally.
- **Client-Side SPA**: Built with React 19, Tailwind CSS v4, Lucide icons, TipTap editor, and Framer Motion layout animations.
- **Storage Layer**: Hybrid support for Firebase Firestore, IndexedDB offline caching, and Cloudflare D1 SQL persistence.
